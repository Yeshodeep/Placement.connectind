
  # Placement Connect India

  This is a code bundle for Placement Connect India. The original project is available at https://www.figma.com/design/1Sj16KJrnVhd2BGnRLTnC5/Placement-Connect-India.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  