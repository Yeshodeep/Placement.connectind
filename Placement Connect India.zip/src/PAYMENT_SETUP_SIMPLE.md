# 💳 Simple Payment Setup (No Verification Required!)

## The Issue You're Facing

Razorpay is asking for "website and app link verification" - **This happens when you try to use "Payment Gateway" integration.**

## ✅ The Solution

Use **Payment Links** or **Payment Pages** instead - these DON'T require any verification!

---

## 🚀 Quick Setup - Payment Links (5 Minutes)

### Step 1: Login to Razorpay
- Go to: https://dashboard.razorpay.com/
- Login or Sign Up

### Step 2: Create Payment Link (Student)
1. Click **"Payment Links"** in left sidebar (NOT Payment Gateway!)
2. Click **"Create Payment Link"** button
3. Fill in:
   ```
   Title: Student Monthly Subscription
   Amount: ₹10.00
   Description: Premium placement drive access
   ```
4. Click **"Create"**
5. **COPY THE LINK** - looks like: `https://rzp.io/l/AbCdEfG`

### Step 3: Create Payment Link (Recruiter)
1. Click **"Create Payment Link"** again
2. Fill in:
   ```
   Title: Recruiter Annual Subscription
   Amount: ₹6999.00
   Description: Post unlimited placement drives
   ```
3. Click **"Create"**
4. **COPY THE LINK** - looks like: `https://rzp.io/l/XyZ1234`

### Step 4: Add Links to Your App
1. Open file: `/config/razorpay.ts`
2. Replace these lines:
   ```typescript
   student_monthly: 'https://rzp.io/l/YOUR_ACTUAL_LINK_HERE',
   recruiter_annual: 'https://rzp.io/l/YOUR_ACTUAL_LINK_HERE',
   ```
3. Save the file
4. Done! ✅

---

## 🎨 Alternative: Payment Pages (Better Looking)

If you want a better-looking payment page with your logo:

### Step 1: Create Payment Page
1. Click **"Payment Pages"** in left sidebar
2. Click **"Create New Page"**
3. Customize:
   - Add your logo
   - Add description
   - Set amount (₹10 or ₹6999)
   - Choose theme/colors
4. Click **"Publish"**
5. **COPY THE PAGE URL**

Use this URL in `/config/razorpay.ts` instead!

---

## ❌ What NOT to Use

### Don't Use These (They Require Verification):
- ❌ Payment Gateway
- ❌ Standard Checkout
- ❌ API Integration
- ❌ Embedded Checkout

### Use These Instead (No Verification):
- ✅ Payment Links
- ✅ Payment Pages
- ✅ Payment Buttons

---

## 🔍 Why Payment Links Work Without Verification

| Feature | Payment Gateway | Payment Links/Pages |
|---------|----------------|---------------------|
| **Website Verification** | ❌ Required | ✅ Not Required |
| **Setup Time** | Hours/Days | 2 Minutes |
| **Works Immediately** | No | ✅ Yes |
| **Hosted By** | Your website | Razorpay |
| **Accepts Payments** | ✅ Yes | ✅ Yes |
| **UPI/Cards/Wallets** | ✅ Yes | ✅ Yes |

---

## 📱 How It Works for Users

1. User clicks "Pay with Razorpay" in your app
2. Opens Razorpay payment page (hosted by Razorpay)
3. User pays using UPI/Card/NetBanking/Wallet
4. Payment goes to your Razorpay account
5. User sees success message
6. You verify payment in dashboard and activate subscription

**No website verification needed at any step!**

---

## 💡 Test Mode (No KYC Required)

Before going live, you can test everything:

1. Toggle **"Test Mode"** ON in Razorpay dashboard
2. Create test payment links
3. Use test payment methods:
   - **UPI**: success@razorpay
   - **Card**: 4111 1111 1111 1111
   - **CVV**: 123
   - **Expiry**: Any future date
4. Test payments won't charge real money

---

## 🎯 What You Can Do Now

### ✅ Immediately:
- Accept payments via UPI
- Accept Credit/Debit cards
- Accept Net Banking
- Accept Wallets (Paytm, PhonePe, etc.)
- Track all payments in dashboard
- Download payment reports
- Get automatic invoices

### ❌ Later (When you want automation):
- Auto-activate subscriptions (needs backend)
- Recurring payments (needs Supabase)
- Custom payment flow (needs verified website)

---

## 🆘 Still Seeing Verification Error?

Make sure you're on the **correct page**:

1. In Razorpay Dashboard, look at left sidebar
2. Click **"Payment Links"** (or "Payment Pages")
3. **NOT** "Payment Gateway"
4. **NOT** "API Keys"

If you're in the right place, you should see a **"Create Payment Link"** button with NO verification warnings!

---

## 📞 Quick Support

- Can't find Payment Links? Look under "Products" → "Payment Links"
- Still stuck? Email: support@razorpay.com
- Or DM on Twitter: @Razorpay

---

## ✅ Final Checklist

- [ ] Logged into Razorpay Dashboard
- [ ] Found "Payment Links" in sidebar (NOT Payment Gateway)
- [ ] Created Student link (₹10)
- [ ] Created Recruiter link (₹6999)
- [ ] Copied both URLs
- [ ] Pasted into `/config/razorpay.ts`
- [ ] Tested by clicking "Subscribe" in app
- [ ] Payment page opens successfully! 🎉

---

**That's it! No verification, no waiting, no complicated setup. Just create links and start accepting payments!** 💰
