# 🎓 Building PlacementConnect India: A Full-Stack Placement Drive Platform

![PlacementConnect India Banner](https://images.unsplash.com/photo-1635246550194-11af93a2763f?w=1200&h=400&fit=crop)

---

## 🌟 Introduction

Hey Dev Community! 👋

I'm excited to share **PlacementConnect India** - a comprehensive web platform that connects students, recruiters, and college administrators across India. Think of it as a modern placement management system that makes discovering and managing campus recruitment drives seamless.

**Live Demo**: [Your deployed URL]
**GitHub**: [Your GitHub repo]

---

## 💡 The Problem

During campus placements in India, I noticed several pain points:

1. **Students** struggle to find placement drives across different colleges and cities
2. **Recruiters** lack a centralized platform to reach talented students nationwide
3. **College administrators** need better tools to track and approve placement activities

PlacementConnect India solves these problems by bringing all stakeholders onto one platform.

---

## ✨ Key Features

### For Students 🎓
- Browse 500+ placement drives from top companies (TCS, Infosys, Amazon, Google, etc.)
- Advanced filtering by location, package, branch, and eligibility
- Interactive map showing drives across Indian cities
- Resume builder with PDF upload
- Application tracking dashboard
- Direct access to HOD information

### For Recruiters 💼
- Post and manage placement drives
- Access to student profiles and resumes
- Analytics dashboard with placement metrics
- Messaging system to connect with students
- Subscription-based model (₹6,999/year)

### For College HODs 🏛️
- Approve/reject placement drives
- Monitor student placement statistics
- Comprehensive student directory
- Track department placement trends
- Post announcements and updates

---

## 🛠️ Tech Stack

I built this using modern web technologies:

```typescript
Frontend:
├── React 18 + TypeScript
├── Tailwind CSS v4
├── Vite (build tool)
├── Recharts (data visualization)
├── Leaflet (interactive maps)
├── Motion (animations)
└── Sonner (toast notifications)

State Management:
└── React Hooks (useState, useEffect)

Data Persistence:
└── LocalStorage (auth & data)

UI Components:
└── Custom component library (shadcn/ui inspired)
```

---

## 🏗️ Architecture Overview

### Component Structure

```
App.tsx (Main Entry Point)
├── Authentication Layer
│   ├── LoginForm
│   ├── SignUpForm
│   └── ForgotPasswordForm
│
├── Student Dashboard
│   ├── PlacementDrives (with filters)
│   ├── MapView
│   ├── ApplicationTracker
│   ├── ResumeBuilder
│   ├── HODInfo
│   └── Notifications
│
├── Recruiter Dashboard
│   ├── PostDrive
│   ├── ManageDrives
│   ├── StudentsDirectory
│   ├── AnalyticsDashboard
│   └── MessagingCenter
│
└── HOD Dashboard
    ├── ApproveDrives
    ├── StudentsManagement
    ├── PlacementAnalytics
    ├── AnnouncementsBoard
    └── Reports
```

### Authentication System

I implemented a complete auth system from scratch:

```typescript
// utils/auth.ts
export interface AuthUser {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'student' | 'recruiter' | 'hod';
  // role-specific fields
}

// Features:
✅ Role-based registration
✅ Email/password validation
✅ Forgot password with temp password generation
✅ Session persistence (localStorage)
✅ Secure logout
```

---

## 🎨 Design Decisions

### 1. Mobile-First Responsive Design

Every component is built with mobile responsiveness in mind:

```tsx
// Flexible tab layouts
<div className="flex flex-wrap gap-2">
  {tabs.map(tab => (
    <TabsTrigger className="flex-1 min-w-[120px]">
      {tab.name}
    </TabsTrigger>
  ))}
</div>
```

### 2. Interactive Map Integration

Used Leaflet for visualizing drives across India:

```typescript
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

// Features:
- City-based clustering
- Custom markers with company logos
- Real-time drive information
- Responsive controls
```

### 3. Real-time Analytics

Built a comprehensive analytics dashboard using Recharts:

```tsx
<ResponsiveContainer width="100%" height={300}>
  <BarChart data={placementTrends}>
    <CartesianGrid strokeDasharray="3 3" />
    <XAxis dataKey="month" />
    <YAxis />
    <Tooltip />
    <Bar dataKey="placements" fill="#8884d8" />
  </BarChart>
</ResponsiveContainer>
```

---

## 🚀 Implementation Highlights

### 1. Resume Upload & Download

```typescript
// Upload resume
const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
  const file = e.target.files?.[0];
  if (file && file.type === 'application/pdf') {
    const url = URL.createObjectURL(file);
    // Store in localStorage or upload to server
    updateStudentResume(studentId, url);
    toast.success('Resume uploaded successfully!');
  }
};

// Download resume
const handleDownload = (resumeUrl: string, studentName: string) => {
  const link = document.createElement('a');
  link.href = resumeUrl;
  link.download = `${studentName}_Resume.pdf`;
  link.click();
  toast.success('Resume downloaded!');
};
```

### 2. Advanced Filtering System

```typescript
const filteredDrives = drives.filter(drive => {
  const matchesCity = !cityFilter || drive.city === cityFilter;
  const matchesCompany = !companyFilter || drive.company === companyFilter;
  const matchesBranch = !branchFilter || 
    drive.eligibility.branches.includes(branchFilter);
  const matchesPackage = drive.package.min >= minPackage;
  
  return matchesCity && matchesCompany && matchesBranch && matchesPackage;
});
```

### 3. Subscription Management

```typescript
// Mock Razorpay integration
const handleSubscription = (plan: 'monthly' | 'annual') => {
  const amount = plan === 'monthly' ? 10 : 6999;
  
  // In production, integrate with Razorpay API
  const options = {
    key: 'rzp_test_key',
    amount: amount * 100, // Convert to paise
    currency: 'INR',
    name: 'PlacementConnect India',
    // ... other options
  };
  
  const razorpay = new Razorpay(options);
  razorpay.open();
};
```

---

## 🎯 Challenges & Solutions

### Challenge 1: Managing Three Different User Roles

**Solution**: Created a unified authentication system with role-based access control:

```typescript
const [userRole, setUserRole] = useState<UserRole>(null);

// Render different dashboards based on role
{userRole === 'student' && <StudentDashboard />}
{userRole === 'recruiter' && <RecruiterDashboard />}
{userRole === 'hod' && <HODDashboard />}
```

### Challenge 2: Responsive Tab Layouts

**Solution**: Used flexible wrapping instead of rigid grids:

```css
/* Instead of grid-cols-6 */
display: grid;
grid-template-columns: repeat(6, 1fr);

/* Use flex with wrap */
display: flex;
flex-wrap: wrap;
gap: 0.5rem;
```

### Challenge 3: Mock Data That Feels Real

**Solution**: Created realistic Indian context data:

```typescript
const companies = ['TCS', 'Infosys', 'Wipro', 'Amazon India', 'Flipkart'];
const cities = ['Mumbai', 'Bangalore', 'Delhi', 'Hyderabad', 'Chennai'];
const colleges = ['IIT Delhi', 'NIT Trichy', 'BITS Pilani'];
const packages = { min: 3, max: 50 }; // LPA
```

---

## 📊 Performance Optimizations

1. **Code Splitting**: Using React lazy loading for heavy components
2. **Tailwind Purging**: Only include used CSS classes
3. **Image Optimization**: Using Unsplash optimized URLs
4. **LocalStorage Caching**: Reduce re-renders with persisted state
5. **Vite Build**: Fast HMR and optimized production builds

---

## 🔐 Security Considerations

⚠️ **Important Note**: This is a demo application. For production:

```typescript
// Current (Demo)
- Passwords stored in plain text
- Data in localStorage
- No server-side validation

// Production Requirements
✅ Hash passwords (bcrypt)
✅ Use JWT tokens
✅ Implement proper backend API
✅ Database (PostgreSQL/MongoDB)
✅ HTTPS encryption
✅ Input sanitization
✅ CORS configuration
✅ Rate limiting
```

---

## 🚀 Deployment

I've prepared comprehensive deployment guides for multiple platforms:

```bash
# Vercel (Recommended)
vercel deploy

# Netlify
npm run build
netlify deploy --prod

# GitHub Pages
npm run deploy
```

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed instructions.

---

## 🎓 What I Learned

1. **Complex State Management**: Handling multiple user roles and their interactions
2. **Responsive Design**: Building truly mobile-first interfaces
3. **TypeScript Best Practices**: Strong typing for better code quality
4. **Authentication Flows**: Implementing signup, login, and password reset
5. **Data Visualization**: Creating meaningful charts and analytics
6. **Map Integration**: Working with Leaflet and geolocation data

---

## 🔮 Future Enhancements

### Planned Features
- [ ] Real backend API with database
- [ ] Email notifications system
- [ ] Real-time chat messaging
- [ ] Video interview scheduling
- [ ] Resume templates and builder
- [ ] Company reviews and ratings
- [ ] Regional language support (Hindi, Tamil, etc.)
- [ ] Mobile app (React Native)
- [ ] AI-powered job matching
- [ ] Placement preparation resources

### Backend Architecture (Planned)
```
Backend:
├── Node.js + Express
├── PostgreSQL (database)
├── JWT authentication
├── Socket.io (real-time features)
├── AWS S3 (file storage)
├── SendGrid (emails)
└── Redis (caching)
```

---

## 🤝 Contributing

This is an open-source project! Contributions are welcome:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

See [CONTRIBUTING.md](./CONTRIBUTING.md) for detailed guidelines.

---

## 📝 Key Takeaways

### For Aspiring Developers:

1. **Start with MVP**: I focused on core features first
2. **User-Centric Design**: Built for real Indian placement scenarios
3. **Clean Code**: Organized components and utilities properly
4. **Documentation**: README and guides are crucial
5. **Iterative Development**: Built and improved incrementally

### Technical Insights:

```typescript
// Good practices I followed:
✅ TypeScript for type safety
✅ Component composition
✅ Custom hooks for reusable logic
✅ Proper error handling
✅ Responsive design from start
✅ Accessibility considerations
✅ Performance optimization
```

---

## 🌐 Links & Resources

- **Live Demo**: [your-demo-url.com]
- **GitHub Repo**: [github.com/username/placementconnect-india]
- **Documentation**: [See README.md]
- **Deployment Guide**: [See DEPLOYMENT.md]

---

## 💬 Let's Connect!

I'd love to hear your feedback and ideas:

- **LinkedIn**: [Your LinkedIn]
- **Twitter**: [@yourhandle]
- **Email**: your.email@example.com
- **Dev.to**: [@yourhandle]

---

## 🙏 Acknowledgments

- Built with React, TypeScript, and Tailwind CSS
- UI components inspired by shadcn/ui
- Icons from Lucide
- Maps by Leaflet
- Charts by Recharts
- Images from Unsplash

---

## ⭐ Show Your Support

If you found this helpful:
- ⭐ Star the GitHub repository
- 🔄 Share with your network
- 💬 Drop a comment below
- 🤝 Contribute to the project

---

**Made with ❤️ for the Indian student community**

---

## 📊 Stats

- **Lines of Code**: ~8,000+
- **Components**: 20+
- **Features**: 30+
- **Development Time**: [Your time]
- **Tech Stack**: 10+ libraries

---

## 🏷️ Tags

#react #typescript #tailwindcss #webdev #india #placement #jobs #careers #education #opensource #portfolio #fullstack #frontend #javascript

---

**What features would you add to this platform? Drop your ideas in the comments! 👇**
