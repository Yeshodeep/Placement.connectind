# 🤝 Contributing to PlacementConnect India

Thank you for your interest in contributing to PlacementConnect India! This document provides guidelines and instructions for contributing to the project.

---

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [How to Contribute](#how-to-contribute)
- [Development Workflow](#development-workflow)
- [Coding Standards](#coding-standards)
- [Commit Guidelines](#commit-guidelines)
- [Pull Request Process](#pull-request-process)
- [Reporting Bugs](#reporting-bugs)
- [Feature Requests](#feature-requests)

---

## 📜 Code of Conduct

### Our Pledge

We are committed to providing a welcoming and inclusive environment for everyone, regardless of:
- Experience level
- Gender identity and expression
- Sexual orientation
- Disability
- Personal appearance
- Body size
- Race
- Ethnicity
- Age
- Religion
- Nationality

### Our Standards

**Positive Behavior:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints
- Gracefully accepting constructive criticism
- Focusing on what's best for the community
- Showing empathy towards others

**Unacceptable Behavior:**
- Harassment, trolling, or discriminatory comments
- Publishing others' private information
- Using sexualized language or imagery
- Other unprofessional conduct

---

## 🚀 Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Git
- Code editor (VS Code recommended)

### Setting Up Your Development Environment

1. **Fork the repository**
   - Click the "Fork" button on GitHub

2. **Clone your fork**
   ```bash
   git clone https://github.com/YOUR_USERNAME/placementconnect-india.git
   cd placementconnect-india
   ```

3. **Add upstream remote**
   ```bash
   git remote add upstream https://github.com/ORIGINAL_OWNER/placementconnect-india.git
   ```

4. **Install dependencies**
   ```bash
   npm install
   ```

5. **Start development server**
   ```bash
   npm run dev
   ```

6. **Open in browser**
   ```
   http://localhost:5173
   ```

---

## 🛠️ How to Contribute

### Types of Contributions

We welcome various types of contributions:

1. **Bug Fixes** - Fix issues and improve stability
2. **New Features** - Add new functionality
3. **Documentation** - Improve README, guides, or code comments
4. **UI/UX Improvements** - Enhance user interface and experience
5. **Performance Optimization** - Make the app faster
6. **Testing** - Add unit tests or integration tests
7. **Accessibility** - Improve accessibility features
8. **Translations** - Add support for regional Indian languages

---

## 🔄 Development Workflow

### 1. Create a Branch

Always create a new branch for your work:

```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/bug-description
```

**Branch Naming Convention:**
- `feature/` - New features (e.g., `feature/resume-templates`)
- `fix/` - Bug fixes (e.g., `fix/login-validation`)
- `docs/` - Documentation (e.g., `docs/api-guide`)
- `refactor/` - Code refactoring (e.g., `refactor/auth-utils`)
- `test/` - Testing (e.g., `test/student-dashboard`)
- `style/` - UI/styling (e.g., `style/responsive-navbar`)

### 2. Make Your Changes

- Write clean, readable code
- Follow existing code style
- Add comments for complex logic
- Update documentation if needed

### 3. Test Your Changes

```bash
# Run development server
npm run dev

# Build for production (check for errors)
npm run build

# Preview production build
npm run preview
```

**Manual Testing Checklist:**
- [ ] All authentication flows work
- [ ] No console errors
- [ ] Responsive on mobile
- [ ] All existing features still work
- [ ] New feature works as expected

### 4. Commit Your Changes

See [Commit Guidelines](#commit-guidelines) below.

### 5. Push to Your Fork

```bash
git push origin feature/your-feature-name
```

### 6. Create Pull Request

- Go to your fork on GitHub
- Click "New Pull Request"
- Fill out the PR template
- Wait for review

---

## 💻 Coding Standards

### TypeScript

- Use TypeScript for type safety
- Define interfaces for all data structures
- Avoid `any` type when possible
- Use proper type imports

```typescript
// Good
import { UserRole } from '../types';
const role: UserRole = 'student';

// Avoid
const role: any = 'student';
```

### React Components

- Use functional components with hooks
- Keep components small and focused
- Use proper prop types

```typescript
// Good
interface StudentCardProps {
  student: StudentProfile;
  onSelect: (id: string) => void;
}

export function StudentCard({ student, onSelect }: StudentCardProps) {
  // Component logic
}
```

### File Organization

```
components/
  ├── ComponentName.tsx       # Main component
  └── ui/                     # Reusable UI components
      ├── button.tsx
      └── card.tsx

utils/
  └── helper.ts               # Utility functions

types/
  └── index.ts                # Type definitions
```

### Tailwind CSS

- Use Tailwind utility classes
- Follow mobile-first approach
- Use existing design tokens
- Avoid inline styles when possible

```tsx
// Good
<div className="flex items-center gap-4 p-4 rounded-lg bg-white shadow-md">

// Avoid
<div style={{ display: 'flex', padding: '16px' }}>
```

### Naming Conventions

- **Components**: PascalCase (`StudentDashboard.tsx`)
- **Functions**: camelCase (`handleLogin`)
- **Constants**: UPPER_SNAKE_CASE (`API_URL`)
- **Files**: kebab-case for utilities (`auth-utils.ts`)
- **CSS Classes**: Tailwind utilities

---

## 📝 Commit Guidelines

### Commit Message Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance tasks

### Examples

```bash
# Feature
git commit -m "feat(auth): add forgot password functionality"

# Bug fix
git commit -m "fix(dashboard): resolve map rendering issue on mobile"

# Documentation
git commit -m "docs(readme): add deployment instructions"

# Multiple changes
git commit -m "refactor(components): reorganize student dashboard tabs

- Simplified tab structure
- Improved responsive layout
- Added better error handling"
```

### Best Practices

- Write clear, descriptive messages
- Use present tense ("add" not "added")
- Keep subject line under 50 characters
- Add detailed description for complex changes
- Reference issue numbers when applicable

```bash
git commit -m "fix(login): resolve email validation bug

Fixes #123
- Added proper email regex validation
- Added error message display
- Updated tests"
```

---

## 🔍 Pull Request Process

### Before Submitting

- [ ] Code follows project style guidelines
- [ ] Self-review of code completed
- [ ] Comments added for complex code
- [ ] Documentation updated if needed
- [ ] No console warnings or errors
- [ ] Tested on multiple screen sizes
- [ ] All authentication flows tested

### PR Template

When creating a PR, include:

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Code refactoring
- [ ] Performance improvement

## Related Issue
Fixes #(issue number)

## Screenshots (if applicable)
Add screenshots for UI changes

## Testing
Describe testing done

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] No breaking changes
- [ ] Tested on mobile
```

### Review Process

1. **Automated Checks** - Wait for any CI/CD checks to pass
2. **Code Review** - Maintainers will review your code
3. **Feedback** - Address any requested changes
4. **Approval** - PR will be approved if all checks pass
5. **Merge** - Maintainers will merge your PR

### After Merge

- Delete your feature branch
- Update your local repository
- Celebrate your contribution! 🎉

---

## 🐛 Reporting Bugs

### Before Reporting

- Check if the bug has already been reported
- Test with the latest version
- Gather reproduction steps

### Bug Report Template

```markdown
## Bug Description
Clear description of the bug

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Scroll to '...'
4. See error

## Expected Behavior
What you expected to happen

## Actual Behavior
What actually happened

## Screenshots
Add screenshots if applicable

## Environment
- Browser: [e.g., Chrome 120]
- OS: [e.g., Windows 11]
- Device: [e.g., Desktop, iPhone 12]
- Screen size: [e.g., 1920x1080]

## Additional Context
Any other relevant information
```

---

## 💡 Feature Requests

We welcome feature ideas! Please include:

1. **Problem Statement** - What problem does this solve?
2. **Proposed Solution** - How would you implement it?
3. **Alternatives** - Other solutions considered?
4. **User Benefit** - Who benefits and how?
5. **Priority** - How important is this feature?

### Feature Request Template

```markdown
## Feature Description
Clear description of the feature

## Problem It Solves
What user problem does this address?

## Proposed Implementation
How would this work?

## User Stories
- As a [student/recruiter/HOD], I want to...
- So that I can...

## Mockups/Examples
Add mockups or examples if applicable

## Additional Context
Any other relevant information
```

---

## 🎯 Priority Areas

We're particularly interested in contributions in these areas:

### High Priority
- Real backend API integration
- Database implementation
- Production-ready authentication
- Email notifications system
- Mobile app version

### Medium Priority
- Additional analytics features
- Advanced filtering options
- Regional language support
- Dark mode
- Accessibility improvements

### Nice to Have
- Resume template builder
- Interview preparation resources
- Company reviews and ratings
- Salary negotiation tools
- Career counseling integration

---

## 🏆 Recognition

Contributors will be:
- Listed in the README
- Mentioned in release notes
- Credited in the project

---

## 📧 Questions?

- Open an issue with the `question` label
- Join our discussions on GitHub Discussions
- Reach out on social media

---

## 📜 License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

**Thank you for contributing to PlacementConnect India! Together, we're building a better placement ecosystem for India. 🇮🇳**
