import { UserRole } from '../types';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  college?: string;
  department?: string;
  company?: string;
  phone?: string;
  createdAt: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
  role: UserRole;
}

export interface SignUpData {
  name: string;
  email: string;
  password: string;
  role: UserRole;
  college?: string;
  department?: string;
  company?: string;
  phone?: string;
}

const STORAGE_KEY = 'placement_connect_users';
const CURRENT_USER_KEY = 'placement_connect_current_user';

// Initialize with some default users for testing
const defaultUsers: AuthUser[] = [
  {
    id: '1',
    name: 'Rahul Sharma',
    email: 'rahul.student@example.com',
    password: 'student123',
    role: 'student',
    college: 'IIT Delhi',
    department: 'Computer Science',
    phone: '+91 9876543210',
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Priya Verma',
    email: 'priya.recruiter@tcs.com',
    password: 'recruiter123',
    role: 'recruiter',
    company: 'Tata Consultancy Services',
    phone: '+91 9876543211',
    createdAt: new Date().toISOString(),
  },
  {
    id: '3',
    name: 'Dr. Amit Kumar',
    email: 'amit.hod@iitdelhi.ac.in',
    password: 'hod123',
    role: 'hod',
    college: 'IIT Delhi',
    department: 'Computer Science',
    phone: '+91 9876543212',
    createdAt: new Date().toISOString(),
  },
];

// Initialize storage with default users if empty
export const initializeAuth = () => {
  const existingUsers = localStorage.getItem(STORAGE_KEY);
  if (!existingUsers) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultUsers));
  }
};

// Get all users
export const getAllUsers = (): AuthUser[] => {
  const users = localStorage.getItem(STORAGE_KEY);
  return users ? JSON.parse(users) : defaultUsers;
};

// Save users to storage
const saveUsers = (users: AuthUser[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
};

// Sign up a new user
export const signUp = (data: SignUpData): { success: boolean; message: string; user?: AuthUser } => {
  const users = getAllUsers();
  
  // Check if email already exists for this role
  const existingUser = users.find(u => u.email === data.email && u.role === data.role);
  if (existingUser) {
    return { success: false, message: 'Email already registered for this role' };
  }

  // Validate required fields based on role
  if (data.role === 'student' && (!data.college || !data.department)) {
    return { success: false, message: 'College and department are required for students' };
  }
  if (data.role === 'recruiter' && !data.company) {
    return { success: false, message: 'Company name is required for recruiters' };
  }
  if (data.role === 'hod' && (!data.college || !data.department)) {
    return { success: false, message: 'College and department are required for HODs' };
  }

  const newUser: AuthUser = {
    ...data,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  saveUsers(users);

  return { success: true, message: 'Account created successfully!', user: newUser };
};

// Login user
export const login = (credentials: LoginCredentials): { success: boolean; message: string; user?: AuthUser } => {
  const users = getAllUsers();
  
  const user = users.find(
    u => u.email === credentials.email && 
         u.password === credentials.password && 
         u.role === credentials.role
  );

  if (!user) {
    return { success: false, message: 'Invalid email, password, or role' };
  }

  // Store current user
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));

  return { success: true, message: 'Login successful!', user };
};

// Get current logged-in user
export const getCurrentUser = (): AuthUser | null => {
  const user = localStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
};

// Logout user
export const logout = () => {
  localStorage.removeItem(CURRENT_USER_KEY);
};

// Reset password
export const resetPassword = (email: string, role: UserRole): { success: boolean; message: string; tempPassword?: string } => {
  const users = getAllUsers();
  const userIndex = users.findIndex(u => u.email === email && u.role === role);

  if (userIndex === -1) {
    return { success: false, message: 'No account found with this email and role' };
  }

  // Generate a temporary password
  const tempPassword = `Temp${Math.random().toString(36).substring(2, 8)}`;
  users[userIndex].password = tempPassword;
  saveUsers(users);

  return { 
    success: true, 
    message: 'Password reset successful! Your temporary password is: ' + tempPassword,
    tempPassword 
  };
};

// Change password
export const changePassword = (userId: string, oldPassword: string, newPassword: string): { success: boolean; message: string } => {
  const users = getAllUsers();
  const userIndex = users.findIndex(u => u.id === userId);

  if (userIndex === -1) {
    return { success: false, message: 'User not found' };
  }

  if (users[userIndex].password !== oldPassword) {
    return { success: false, message: 'Current password is incorrect' };
  }

  users[userIndex].password = newPassword;
  saveUsers(users);

  // Update current user in storage
  const currentUser = getCurrentUser();
  if (currentUser && currentUser.id === userId) {
    currentUser.password = newPassword;
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(currentUser));
  }

  return { success: true, message: 'Password changed successfully!' };
};
