import { PlacementDrive } from '../types';

export const mockPlacementDrives: PlacementDrive[] = [
  {
    id: '1',
    company: 'Tata Consultancy Services',
    position: 'Software Engineer',
    location: 'TCS Campus, Whitefield',
    city: 'Bangalore',
    state: 'Karnataka',
    date: '2025-11-20',
    deadline: '2025-11-15',
    eligibility: {
      degree: ['B.Tech', 'B.E.', 'MCA'],
      minCGPA: 7.0,
      graduationYear: [2025, 2026],
      branches: ['CSE', 'IT', 'ECE', 'EEE']
    },
    package: {
      min: 3.5,
      max: 7.0
    },
    type: 'On-Campus',
    status: 'Open',
    registeredStudents: 245,
    totalSeats: 80,
    colleges: ['IIT Delhi', 'NIT Trichy', 'BITS Pilani'],
    description: 'TCS is hiring talented engineers for various technology roles across different domains.',
    requirements: ['Strong programming skills', 'Good communication', 'Problem-solving ability'],
    rounds: ['Online Test', 'Technical Interview', 'HR Interview'],
    postedBy: 'TCS HR Team',
    postedDate: '2025-10-15',
    approvedByHOD: true,
    coordinates: { lat: 12.9698, lng: 77.7499 }
  },
  {
    id: '2',
    company: 'Infosys',
    position: 'Systems Engineer',
    location: 'Infosys Mysore Campus',
    city: 'Mysore',
    state: 'Karnataka',
    date: '2025-11-25',
    deadline: '2025-11-18',
    eligibility: {
      degree: ['B.Tech', 'B.E.', 'M.Tech', 'MCA'],
      minCGPA: 6.5,
      graduationYear: [2025],
      branches: ['CSE', 'IT', 'ECE', 'EEE', 'Mechanical']
    },
    package: {
      min: 3.6,
      max: 6.5
    },
    type: 'Pool Campus',
    status: 'Open',
    registeredStudents: 512,
    totalSeats: 150,
    colleges: ['Anna University', 'VIT Vellore', 'SRM University', 'PES University'],
    description: 'Infosys Power Programmer opportunity for fresh graduates passionate about technology.',
    requirements: ['Any programming language', 'Logical thinking', 'Team player'],
    rounds: ['Aptitude Test', 'Technical Interview', 'HR Round'],
    postedBy: 'Infosys Recruitment',
    postedDate: '2025-10-20',
    approvedByHOD: true,
    coordinates: { lat: 12.3117, lng: 76.6544 }
  },
  {
    id: '3',
    company: 'Wipro',
    position: 'Project Engineer',
    location: 'Wipro SEZ, Electronic City',
    city: 'Bangalore',
    state: 'Karnataka',
    date: '2025-12-05',
    deadline: '2025-11-28',
    eligibility: {
      degree: ['B.Tech', 'B.E.'],
      minCGPA: 6.0,
      graduationYear: [2025, 2026],
      branches: ['CSE', 'IT', 'ECE']
    },
    package: {
      min: 3.5,
      max: 6.0
    },
    type: 'On-Campus',
    status: 'Upcoming',
    registeredStudents: 189,
    totalSeats: 60,
    colleges: ['PESIT', 'RV College', 'BMS College'],
    description: 'Join Wipro as a Project Engineer and work on cutting-edge technology projects.',
    requirements: ['C/C++/Java proficiency', 'Database knowledge', 'Analytical skills'],
    rounds: ['Written Test', 'Technical + HR Interview'],
    postedBy: 'Wipro Campus Team',
    postedDate: '2025-10-25',
    approvedByHOD: true,
    coordinates: { lat: 12.8458, lng: 77.6638 }
  },
  {
    id: '4',
    company: 'Amazon',
    position: 'Software Development Engineer',
    location: 'Amazon Development Center',
    city: 'Hyderabad',
    state: 'Telangana',
    date: '2025-11-28',
    deadline: '2025-11-20',
    eligibility: {
      degree: ['B.Tech', 'M.Tech'],
      minCGPA: 7.5,
      graduationYear: [2025],
      branches: ['CSE', 'IT']
    },
    package: {
      min: 28.0,
      max: 43.0
    },
    type: 'Off-Campus',
    status: 'Open',
    registeredStudents: 1250,
    totalSeats: 25,
    colleges: ['All Tier 1 & Tier 2 colleges'],
    description: 'Amazon is looking for exceptional engineers to join our world-class team.',
    requirements: ['Strong DSA skills', 'System design knowledge', 'Previous internship preferred'],
    rounds: ['Online Assessment', 'Technical Round 1', 'Technical Round 2', 'Hiring Manager Round'],
    postedBy: 'Amazon India',
    postedDate: '2025-11-01',
    approvedByHOD: false,
    coordinates: { lat: 17.4485, lng: 78.3908 }
  },
  {
    id: '5',
    company: 'Microsoft',
    position: 'Software Engineer',
    location: 'Microsoft India Development Center',
    city: 'Bangalore',
    state: 'Karnataka',
    date: '2025-12-10',
    deadline: '2025-12-01',
    eligibility: {
      degree: ['B.Tech', 'M.Tech'],
      minCGPA: 8.0,
      graduationYear: [2025],
      branches: ['CSE', 'IT']
    },
    package: {
      min: 42.0,
      max: 42.0
    },
    type: 'Off-Campus',
    status: 'Upcoming',
    registeredStudents: 2100,
    totalSeats: 30,
    colleges: ['IITs', 'NITs', 'BITS Pilani', 'IIIT Hyderabad'],
    description: 'Join Microsoft and shape the future of technology with innovative solutions.',
    requirements: ['Excellent coding skills', 'Problem-solving', 'Innovation mindset'],
    rounds: ['Online Coding Test', 'Technical Interviews (3-4)', 'AA Round'],
    postedBy: 'Microsoft University Recruiting',
    postedDate: '2025-11-02',
    approvedByHOD: true,
    coordinates: { lat: 12.9352, lng: 77.6245 }
  },
  {
    id: '6',
    company: 'Cognizant',
    position: 'Programmer Analyst',
    location: 'Cognizant Technology Solutions',
    city: 'Chennai',
    state: 'Tamil Nadu',
    date: '2025-11-22',
    deadline: '2025-11-16',
    eligibility: {
      degree: ['B.Tech', 'B.E.', 'MCA'],
      minCGPA: 6.5,
      graduationYear: [2025, 2026],
      branches: ['CSE', 'IT', 'ECE', 'EEE']
    },
    package: {
      min: 4.0,
      max: 6.5
    },
    type: 'Pool Campus',
    status: 'Open',
    registeredStudents: 678,
    totalSeats: 200,
    colleges: ['Anna University Colleges', 'SRM', 'VIT'],
    description: 'Cognizant GenC program for passionate programmers ready to make an impact.',
    requirements: ['Programming knowledge', 'Communication skills', 'Aptitude'],
    rounds: ['Aptitude + Technical Test', 'Technical Interview', 'HR Interview'],
    postedBy: 'Cognizant Campus Hiring',
    postedDate: '2025-10-18',
    approvedByHOD: true,
    coordinates: { lat: 13.0827, lng: 80.2707 }
  },
  {
    id: '7',
    company: 'Flipkart',
    position: 'SDE - 1',
    location: 'Flipkart Internet Pvt Ltd',
    city: 'Bangalore',
    state: 'Karnataka',
    date: '2025-12-01',
    deadline: '2025-11-22',
    eligibility: {
      degree: ['B.Tech', 'M.Tech'],
      minCGPA: 7.0,
      graduationYear: [2025],
      branches: ['CSE', 'IT']
    },
    package: {
      min: 15.0,
      max: 24.0
    },
    type: 'Off-Campus',
    status: 'Open',
    registeredStudents: 892,
    totalSeats: 40,
    colleges: ['Open to all colleges'],
    description: 'Build the future of e-commerce with Flipkart. Work on massive scale systems.',
    requirements: ['Strong DSA', 'System design basics', 'Java/Python/Go'],
    rounds: ['Online Test', 'Technical Round 1', 'Technical Round 2', 'Hiring Manager'],
    postedBy: 'Flipkart Talent Acquisition',
    postedDate: '2025-10-28',
    approvedByHOD: false,
    coordinates: { lat: 12.9719, lng: 77.5937 }
  },
  {
    id: '8',
    company: 'Accenture',
    position: 'Application Development Associate',
    location: 'Accenture Solutions Pvt Ltd',
    city: 'Pune',
    state: 'Maharashtra',
    date: '2025-11-18',
    deadline: '2025-11-12',
    eligibility: {
      degree: ['B.Tech', 'B.E.', 'MCA', 'M.Tech'],
      minCGPA: 6.0,
      graduationYear: [2025],
      branches: ['All branches']
    },
    package: {
      min: 4.5,
      max: 6.0
    },
    type: 'Pool Campus',
    status: 'Open',
    registeredStudents: 1456,
    totalSeats: 300,
    colleges: ['Maharashtra Colleges', 'Karnataka Colleges'],
    description: 'Accenture is hiring talented graduates for various technology and consulting roles.',
    requirements: ['Good communication', 'Analytical skills', 'Willingness to learn'],
    rounds: ['Cognitive & Technical Assessment', 'Communication Assessment', 'Interview'],
    postedBy: 'Accenture India Hiring',
    postedDate: '2025-10-10',
    approvedByHOD: true,
    coordinates: { lat: 18.5204, lng: 73.8567 }
  },
  {
    id: '9',
    company: 'Adobe',
    position: 'Member of Technical Staff',
    location: 'Adobe Systems India',
    city: 'Noida',
    state: 'Uttar Pradesh',
    date: '2025-12-15',
    deadline: '2025-12-05',
    eligibility: {
      degree: ['B.Tech', 'M.Tech'],
      minCGPA: 8.0,
      graduationYear: [2025],
      branches: ['CSE', 'IT']
    },
    package: {
      min: 24.0,
      max: 36.0
    },
    type: 'Off-Campus',
    status: 'Upcoming',
    registeredStudents: 756,
    totalSeats: 15,
    colleges: ['Premier Engineering Colleges'],
    description: 'Join Adobe and create digital experiences that transform the world.',
    requirements: ['Excellent coding', 'Computer science fundamentals', 'Portfolio preferred'],
    rounds: ['Online Test', 'Technical Rounds (2-3)', 'HR Round'],
    postedBy: 'Adobe University Relations',
    postedDate: '2025-11-03',
    approvedByHOD: true,
    coordinates: { lat: 28.5355, lng: 77.3910 }
  },
  {
    id: '10',
    company: 'Capgemini',
    position: 'Analyst',
    location: 'Capgemini Technology Services',
    city: 'Mumbai',
    state: 'Maharashtra',
    date: '2025-11-30',
    deadline: '2025-11-23',
    eligibility: {
      degree: ['B.Tech', 'B.E.', 'MCA'],
      minCGPA: 6.5,
      graduationYear: [2025, 2026],
      branches: ['CSE', 'IT', 'ECE', 'EEE', 'Mechanical']
    },
    package: {
      min: 3.8,
      max: 6.5
    },
    type: 'Pool Campus',
    status: 'Upcoming',
    registeredStudents: 523,
    totalSeats: 120,
    colleges: ['Mumbai University Colleges', 'Pune Colleges'],
    description: 'Capgemini is looking for bright minds to join our global team.',
    requirements: ['Technical aptitude', 'Problem-solving', 'Team collaboration'],
    rounds: ['Online Assessment', 'Technical + HR Interview'],
    postedBy: 'Capgemini India Recruitment',
    postedDate: '2025-10-22',
    approvedByHOD: true,
    coordinates: { lat: 19.0760, lng: 72.8777 }
  }
];

export const indianCities = [
  'Bangalore', 'Hyderabad', 'Chennai', 'Mumbai', 'Pune', 
  'Delhi', 'Noida', 'Gurgaon', 'Kolkata', 'Mysore',
  'Coimbatore', 'Kochi', 'Jaipur', 'Ahmedabad', 'Chandigarh'
];

export const indianStates = [
  'Karnataka', 'Telangana', 'Tamil Nadu', 'Maharashtra', 
  'Delhi', 'Uttar Pradesh', 'West Bengal', 'Kerala',
  'Rajasthan', 'Gujarat', 'Punjab', 'Haryana'
];

export const branches = [
  'CSE', 'IT', 'ECE', 'EEE', 'Mechanical', 'Civil',
  'Chemical', 'Biotechnology', 'Instrumentation'
];

export const companies = [
  'TCS', 'Infosys', 'Wipro', 'Cognizant', 'Accenture',
  'Amazon', 'Microsoft', 'Google', 'Adobe', 'Flipkart',
  'Walmart', 'Oracle', 'SAP', 'IBM', 'Deloitte'
];

export const mockApplications = [
  {
    id: 'app1',
    driveId: '1',
    studentId: 'stu1',
    studentName: 'Rahul Kumar',
    studentEmail: 'rahul@example.com',
    studentPhone: '+91 9876543210',
    cgpa: 8.5,
    branch: 'CSE',
    graduationYear: 2025,
    resumeUrl: '/documents/rahul_resume.pdf',
    status: 'Shortlisted' as const,
    appliedDate: '2025-10-20',
    lastUpdated: '2025-11-05',
    notes: 'Strong candidate with good projects',
    interviewDate: '2025-11-22'
  },
  {
    id: 'app2',
    driveId: '1',
    studentId: 'stu2',
    studentName: 'Priya Sharma',
    studentEmail: 'priya@example.com',
    studentPhone: '+91 9876543211',
    cgpa: 7.8,
    branch: 'IT',
    graduationYear: 2025,
    status: 'Applied' as const,
    appliedDate: '2025-10-22',
    lastUpdated: '2025-10-22'
  },
  {
    id: 'app3',
    driveId: '2',
    studentId: 'stu1',
    studentName: 'Rahul Kumar',
    studentEmail: 'rahul@example.com',
    studentPhone: '+91 9876543210',
    cgpa: 8.5,
    branch: 'CSE',
    graduationYear: 2025,
    status: 'Interview Scheduled' as const,
    appliedDate: '2025-10-18',
    lastUpdated: '2025-11-03',
    interviewDate: '2025-11-20'
  }
];

export const mockNotifications = [
  {
    id: 'notif1',
    userId: 'stu1',
    type: 'application' as const,
    title: 'Application Status Update',
    message: 'Your application for TCS Software Engineer has been shortlisted!',
    read: false,
    createdAt: '2025-11-05T10:30:00Z',
    actionUrl: '/applications/app1'
  },
  {
    id: 'notif2',
    userId: 'stu1',
    type: 'interview' as const,
    title: 'Interview Scheduled',
    message: 'Your interview for Infosys is scheduled on Nov 20, 2025 at 10:00 AM',
    read: false,
    createdAt: '2025-11-03T14:20:00Z',
    actionUrl: '/applications/app3'
  },
  {
    id: 'notif3',
    userId: 'stu1',
    type: 'drive' as const,
    title: 'New Placement Drive',
    message: 'Amazon is conducting a placement drive in Bangalore',
    read: true,
    createdAt: '2025-10-28T09:00:00Z',
    actionUrl: '/drives/3'
  }
];

export const mockMessages = [
  {
    id: 'msg1',
    conversationId: 'conv1',
    senderId: 'stu1',
    senderName: 'Rahul Kumar',
    senderRole: 'student' as const,
    receiverId: 'rec1',
    content: 'Hello, I have a query regarding the eligibility criteria',
    timestamp: '2025-11-05T10:00:00Z',
    read: true
  },
  {
    id: 'msg2',
    conversationId: 'conv1',
    senderId: 'rec1',
    senderName: 'TCS Recruiter',
    senderRole: 'recruiter' as const,
    receiverId: 'stu1',
    content: 'Sure, please let me know your question',
    timestamp: '2025-11-05T10:15:00Z',
    read: true
  }
];

export const mockConversations = [
  {
    id: 'conv1',
    participants: [
      { id: 'stu1', name: 'Rahul Kumar', role: 'student' as const },
      { id: 'rec1', name: 'TCS Recruiter', role: 'recruiter' as const }
    ],
    lastMessage: 'Sure, please let me know your question',
    lastMessageTime: '2025-11-05T10:15:00Z',
    unreadCount: 0,
    driveId: '1'
  }
];

export const mockDocuments = [
  {
    id: 'doc1',
    userId: 'stu1',
    type: 'resume' as const,
    name: 'Rahul_Kumar_Resume.pdf',
    url: '/documents/rahul_resume.pdf',
    uploadedAt: '2025-10-15T08:00:00Z',
    size: 245678,
    verified: true
  },
  {
    id: 'doc2',
    userId: 'stu1',
    type: 'certificate' as const,
    name: 'AWS_Certificate.pdf',
    url: '/documents/aws_cert.pdf',
    uploadedAt: '2025-10-20T12:00:00Z',
    size: 156789,
    verified: false
  }
];

export const mockAnnouncements = [
  {
    id: 'ann1',
    authorId: 'hod1',
    authorName: 'Dr. Ramesh Kumar',
    authorRole: 'hod' as const,
    title: 'Important: Placement Registration Deadline',
    content: 'All students must complete their placement registration by November 15, 2025. Late registrations will not be accepted.',
    type: 'urgent' as const,
    targetAudience: ['student' as const],
    createdAt: '2025-11-01T09:00:00Z',
    isPinned: true
  },
  {
    id: 'ann2',
    authorId: 'rec1',
    authorName: 'TCS HR Team',
    authorRole: 'recruiter' as const,
    title: 'Pre-Placement Talk Scheduled',
    content: 'Join us for a pre-placement talk on November 18, 2025 at 3:00 PM in the Main Auditorium.',
    type: 'event' as const,
    targetAudience: ['student' as const, 'hod' as const],
    createdAt: '2025-11-03T11:00:00Z',
    expiresAt: '2025-11-18T23:59:59Z',
    isPinned: false
  }
];

export const mockAnalytics = {
  totalDrives: 10,
  activeDrives: 6,
  totalApplications: 1247,
  successRate: 68.5,
  drivesByStatus: {
    'Open': 4,
    'Upcoming': 2,
    'Closed': 2,
    'Completed': 2
  },
  drivesByType: {
    'On-Campus': 5,
    'Off-Campus': 3,
    'Pool Campus': 2
  },
  applicationsByStatus: {
    'Applied': 456,
    'Shortlisted': 234,
    'Interview Scheduled': 123,
    'Selected': 189,
    'Rejected': 245
  },
  topCompanies: [
    { name: 'TCS', count: 245 },
    { name: 'Infosys', count: 189 },
    { name: 'Amazon', count: 156 },
    { name: 'Microsoft', count: 134 },
    { name: 'Wipro', count: 128 }
  ],
  placementTrends: [
    { month: 'Jun', placements: 45 },
    { month: 'Jul', placements: 67 },
    { month: 'Aug', placements: 89 },
    { month: 'Sep', placements: 123 },
    { month: 'Oct', placements: 156 },
    { month: 'Nov', placements: 178 }
  ],
  packageDistribution: [
    { range: '0-5 LPA', count: 234 },
    { range: '5-10 LPA', count: 456 },
    { range: '10-15 LPA', count: 289 },
    { range: '15-20 LPA', count: 145 },
    { range: '20+ LPA', count: 123 }
  ],
  cityWiseData: [
    { city: 'Bangalore', drives: 28 },
    { city: 'Hyderabad', drives: 22 },
    { city: 'Pune', drives: 18 },
    { city: 'Chennai', drives: 15 },
    { city: 'Mumbai', drives: 14 }
  ]
};

export const mockStudentProfile = {
  id: 'stu1',
  name: 'Rahul Kumar',
  email: 'rahul@example.com',
  phone: '+91 9876543210',
  college: 'IIT Delhi',
  branch: 'CSE',
  batch: '2021-2025',
  semester: 8,
  cgpa: 8.5,
  graduationYear: 2025,
  skills: ['React', 'Node.js', 'Python', 'Machine Learning', 'AWS'],
  preferredLocations: ['Bangalore', 'Hyderabad', 'Pune'],
  preferredCompanies: ['Amazon', 'Microsoft', 'Google', 'Adobe'],
  minPackage: 10,
  resumeUrl: '/documents/rahul_resume.pdf',
  photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
  tenthMarks: 92.5,
  twelfthMarks: 88.0,
  backlogs: 0,
  internships: ['Amazon SDE Intern (Summer 2024)', 'Google STEP Intern (Winter 2023)'],
  projects: ['E-commerce Platform using MERN', 'ML-based Recommendation System', 'Cloud-based File Storage']
};

export const mockStudentProfiles = [
  {
    id: 'stu1',
    name: 'Rahul Kumar',
    email: 'rahul.kumar@iitd.ac.in',
    phone: '+91 9876543210',
    college: 'IIT Delhi',
    branch: 'Computer Science',
    batch: '2021-2025',
    semester: 8,
    cgpa: 8.5,
    graduationYear: 2025,
    skills: ['React', 'Node.js', 'Python', 'Machine Learning', 'AWS'],
    preferredLocations: ['Bangalore', 'Hyderabad', 'Pune'],
    preferredCompanies: ['Amazon', 'Microsoft', 'Google', 'Adobe'],
    minPackage: 10,
    resumeUrl: '/documents/rahul_resume.pdf',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
    tenthMarks: 92.5,
    twelfthMarks: 88.0,
    backlogs: 0,
    internships: ['Amazon SDE Intern (Summer 2024)', 'Google STEP Intern (Winter 2023)'],
    projects: ['E-commerce Platform using MERN', 'ML-based Recommendation System']
  },
  {
    id: 'stu2',
    name: 'Priya Sharma',
    email: 'priya.sharma@iitd.ac.in',
    phone: '+91 9876543211',
    college: 'IIT Delhi',
    branch: 'Electronics & Communication',
    batch: '2021-2025',
    semester: 8,
    cgpa: 9.1,
    graduationYear: 2025,
    skills: ['VLSI Design', 'Embedded Systems', 'Python', 'C++', 'MATLAB'],
    preferredLocations: ['Bangalore', 'Noida', 'Hyderabad'],
    preferredCompanies: ['Intel', 'Qualcomm', 'Texas Instruments', 'Samsung'],
    minPackage: 12,
    resumeUrl: '/documents/priya_resume.pdf',
    photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    tenthMarks: 95.0,
    twelfthMarks: 94.5,
    backlogs: 0,
    internships: ['Intel Hardware Intern (Summer 2024)', 'IISc Research Intern (Winter 2023)'],
    projects: ['FPGA-based Image Processing', 'IoT Smart Home System']
  },
  {
    id: 'stu3',
    name: 'Arjun Patel',
    email: 'arjun.patel@iitd.ac.in',
    phone: '+91 9876543212',
    college: 'IIT Delhi',
    branch: 'Information Technology',
    batch: '2022-2026',
    semester: 6,
    cgpa: 8.2,
    graduationYear: 2026,
    skills: ['Java', 'Spring Boot', 'Docker', 'Kubernetes', 'MySQL'],
    preferredLocations: ['Pune', 'Bangalore', 'Mumbai'],
    preferredCompanies: ['TCS', 'Infosys', 'Wipro', 'Cognizant'],
    minPackage: 6,
    resumeUrl: '/documents/arjun_resume.pdf',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop',
    tenthMarks: 88.0,
    twelfthMarks: 85.5,
    backlogs: 1,
    internships: ['TCS Digital Intern (Summer 2024)'],
    projects: ['Microservices Architecture for Banking', 'DevOps CI/CD Pipeline']
  },
  {
    id: 'stu4',
    name: 'Sneha Reddy',
    email: 'sneha.reddy@iitd.ac.in',
    phone: '+91 9876543213',
    college: 'IIT Delhi',
    branch: 'Computer Science',
    batch: '2021-2025',
    semester: 8,
    cgpa: 8.8,
    graduationYear: 2025,
    skills: ['React Native', 'Flutter', 'Firebase', 'MongoDB', 'Node.js'],
    preferredLocations: ['Hyderabad', 'Bangalore', 'Chennai'],
    preferredCompanies: ['Flipkart', 'Swiggy', 'PhonePe', 'Paytm'],
    minPackage: 8,
    resumeUrl: '/documents/sneha_resume.pdf',
    photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
    tenthMarks: 90.0,
    twelfthMarks: 89.0,
    backlogs: 0,
    internships: ['Flipkart Mobile App Intern (Summer 2024)', 'Razorpay Backend Intern (Winter 2023)'],
    projects: ['Social Media Mobile App', 'Food Delivery Platform', 'Payment Gateway Integration']
  },
  {
    id: 'stu5',
    name: 'Vikram Singh',
    email: 'vikram.singh@iitd.ac.in',
    phone: '+91 9876543214',
    college: 'IIT Delhi',
    branch: 'Electrical Engineering',
    batch: '2022-2026',
    semester: 6,
    cgpa: 7.8,
    graduationYear: 2026,
    skills: ['Power Systems', 'MATLAB', 'Python', 'AutoCAD', 'PLC Programming'],
    preferredLocations: ['Delhi', 'Mumbai', 'Bangalore'],
    preferredCompanies: ['Siemens', 'ABB', 'Schneider Electric', 'L&T'],
    minPackage: 7,
    resumeUrl: '/documents/vikram_resume.pdf',
    photo: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop',
    tenthMarks: 85.0,
    twelfthMarks: 83.0,
    backlogs: 2,
    internships: ['Siemens Power Systems Intern (Summer 2024)'],
    projects: ['Smart Grid Monitoring System', 'Renewable Energy Integration']
  }
];

export const mockHODProfiles = [
  {
    id: 'hod1',
    name: 'Dr. Rajesh Verma',
    email: 'rajesh.verma@iitd.ac.in',
    phone: '+91 11-2659-1234',
    college: 'Indian Institute of Technology Delhi',
    collegeLogo: 'https://upload.wikimedia.org/wikipedia/en/f/fd/Indian_Institute_of_Technology_Delhi_Logo.svg',
    department: 'Computer Science & Engineering',
    designation: 'Head of Department & Professor',
    experience: 22,
    qualifications: ['Ph.D. in Computer Science (Stanford)', 'M.Tech in CSE (IIT Bombay)', 'B.Tech in CSE (IIT Delhi)'],
    specialization: ['Artificial Intelligence', 'Machine Learning', 'Data Mining', 'Computer Vision'],
    photo: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=150&h=150&fit=crop',
    officeAddress: 'Block V, Room 402, IIT Delhi Campus, Hauz Khas, New Delhi - 110016',
    officeHours: 'Monday to Friday: 10:00 AM - 5:00 PM',
    totalStudents: 650,
    placedStudents: 589,
    averagePackage: 18.5
  },
  {
    id: 'hod2',
    name: 'Dr. Meera Krishnan',
    email: 'meera.krishnan@iitm.ac.in',
    phone: '+91 44-2257-8000',
    college: 'Indian Institute of Technology Madras',
    collegeLogo: 'https://upload.wikimedia.org/wikipedia/en/6/69/IIT_Madras_Logo.svg',
    department: 'Electronics & Communication Engineering',
    designation: 'Head of Department & Associate Professor',
    experience: 18,
    qualifications: ['Ph.D. in ECE (MIT)', 'M.Tech in Communication Systems (IIT Madras)', 'B.E. in ECE (Anna University)'],
    specialization: ['Wireless Communications', '5G Networks', 'Signal Processing', 'IoT Systems'],
    photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&h=150&fit=crop',
    officeAddress: 'Department of ECE, IIT Madras, Chennai - 600036',
    officeHours: 'Monday to Friday: 9:30 AM - 4:30 PM',
    totalStudents: 480,
    placedStudents: 445,
    averagePackage: 14.2
  },
  {
    id: 'hod3',
    name: 'Dr. Amit Kulkarni',
    email: 'amit.kulkarni@nitk.ac.in',
    phone: '+91 824-247-4000',
    college: 'National Institute of Technology Karnataka',
    collegeLogo: 'https://upload.wikimedia.org/wikipedia/en/c/c9/NITK_Emblem.png',
    department: 'Information Technology',
    designation: 'Head of Department & Professor',
    experience: 20,
    qualifications: ['Ph.D. in IT (IISc Bangalore)', 'M.Tech in IT (NIT Surathkal)', 'B.Tech in IT (VJTI Mumbai)'],
    specialization: ['Cloud Computing', 'Distributed Systems', 'Cybersecurity', 'Software Engineering'],
    photo: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop',
    officeAddress: 'IT Department, NIT Karnataka, Surathkal, Mangalore - 575025',
    officeHours: 'Monday to Friday: 10:00 AM - 5:00 PM, Saturday: 10:00 AM - 1:00 PM',
    totalStudents: 420,
    placedStudents: 385,
    averagePackage: 12.8
  }
];