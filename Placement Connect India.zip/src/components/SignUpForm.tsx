import { useState } from 'react';
import { UserRole } from '../types';
import { SignUpData, signUp } from '../utils/auth';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { GraduationCap, Building2, UserCheck, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface SignUpFormProps {
  role: UserRole;
  onSuccess: () => void;
  onBackToLogin: () => void;
}

export function SignUpForm({ role, onSuccess, onBackToLogin }: SignUpFormProps) {
  const [formData, setFormData] = useState<SignUpData>({
    name: '',
    email: '',
    password: '',
    role,
    college: '',
    department: '',
    company: '',
    phone: '',
  });
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Validate passwords match
    if (formData.password !== confirmPassword) {
      toast.error('Passwords do not match');
      setIsSubmitting(false);
      return;
    }

    // Validate password strength
    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters long');
      setIsSubmitting(false);
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error('Please enter a valid email address');
      setIsSubmitting(false);
      return;
    }

    // Attempt sign up
    const result = signUp(formData);
    
    if (result.success) {
      toast.success(result.message);
      setTimeout(() => {
        onSuccess();
      }, 1000);
    } else {
      toast.error(result.message);
    }

    setIsSubmitting(false);
  };

  const handleChange = (field: keyof SignUpData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const getRoleIcon = () => {
    switch (role) {
      case 'student':
        return <GraduationCap className="h-8 w-8 text-blue-600" />;
      case 'recruiter':
        return <Building2 className="h-8 w-8 text-purple-600" />;
      case 'hod':
        return <UserCheck className="h-8 w-8 text-green-600" />;
    }
  };

  const getRoleBgColor = () => {
    switch (role) {
      case 'student':
        return 'bg-blue-100';
      case 'recruiter':
        return 'bg-purple-100';
      case 'hod':
        return 'bg-green-100';
    }
  };

  const getRoleTitle = () => {
    switch (role) {
      case 'student':
        return 'Student Registration';
      case 'recruiter':
        return 'Recruiter Registration';
      case 'hod':
        return 'College HOD Registration';
    }
  };

  return (
    <Card className="p-8 max-w-md mx-auto">
      <Button
        variant="ghost"
        size="sm"
        onClick={onBackToLogin}
        className="mb-4 gap-2"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Login
      </Button>

      <div className="text-center mb-6">
        <div className={`${getRoleBgColor()} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
          {getRoleIcon()}
        </div>
        <h2 className="text-2xl mb-2">{getRoleTitle()}</h2>
        <p className="text-sm text-muted-foreground">
          Create your account to get started
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Name */}
        <div className="space-y-2">
          <Label htmlFor="name">Full Name *</Label>
          <Input
            id="name"
            type="text"
            placeholder="Enter your full name"
            value={formData.name}
            onChange={(e) => handleChange('name', e.target.value)}
            required
          />
        </div>

        {/* Email */}
        <div className="space-y-2">
          <Label htmlFor="email">Email Address *</Label>
          <Input
            id="email"
            type="email"
            placeholder="your.email@example.com"
            value={formData.email}
            onChange={(e) => handleChange('email', e.target.value)}
            required
          />
        </div>

        {/* Phone */}
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number *</Label>
          <Input
            id="phone"
            type="tel"
            placeholder="+91 9876543210"
            value={formData.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            required
          />
        </div>

        {/* Role-specific fields */}
        {role === 'student' && (
          <>
            <div className="space-y-2">
              <Label htmlFor="college">College Name *</Label>
              <Input
                id="college"
                type="text"
                placeholder="e.g., IIT Delhi"
                value={formData.college}
                onChange={(e) => handleChange('college', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="department">Department/Branch *</Label>
              <Input
                id="department"
                type="text"
                placeholder="e.g., Computer Science"
                value={formData.department}
                onChange={(e) => handleChange('department', e.target.value)}
                required
              />
            </div>
          </>
        )}

        {role === 'recruiter' && (
          <div className="space-y-2">
            <Label htmlFor="company">Company Name *</Label>
            <Input
              id="company"
              type="text"
              placeholder="e.g., TCS, Infosys, Amazon"
              value={formData.company}
              onChange={(e) => handleChange('company', e.target.value)}
              required
            />
          </div>
        )}

        {role === 'hod' && (
          <>
            <div className="space-y-2">
              <Label htmlFor="college">College Name *</Label>
              <Input
                id="college"
                type="text"
                placeholder="e.g., IIT Delhi"
                value={formData.college}
                onChange={(e) => handleChange('college', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="department">Department *</Label>
              <Input
                id="department"
                type="text"
                placeholder="e.g., Computer Science"
                value={formData.department}
                onChange={(e) => handleChange('department', e.target.value)}
                required
              />
            </div>
          </>
        )}

        {/* Password */}
        <div className="space-y-2">
          <Label htmlFor="password">Password *</Label>
          <Input
            id="password"
            type="password"
            placeholder="Minimum 6 characters"
            value={formData.password}
            onChange={(e) => handleChange('password', e.target.value)}
            required
            minLength={6}
          />
        </div>

        {/* Confirm Password */}
        <div className="space-y-2">
          <Label htmlFor="confirmPassword">Confirm Password *</Label>
          <Input
            id="confirmPassword"
            type="password"
            placeholder="Re-enter your password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            minLength={6}
          />
        </div>

        <Button
          type="submit"
          className="w-full"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Creating Account...' : 'Create Account'}
        </Button>
      </form>
    </Card>
  );
}
