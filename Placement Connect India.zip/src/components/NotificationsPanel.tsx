import { useState } from 'react';
import { Notification } from '../types';
import { mockNotifications } from '../data/mockData';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  Bell,
  BellOff,
  Check,
  CheckCheck,
  Trash2,
  Calendar,
  Briefcase,
  MessageSquare,
  AlertCircle,
  Settings
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

const notificationIcons = {
  drive: Briefcase,
  application: CheckCheck,
  interview: Calendar,
  announcement: MessageSquare,
  system: Settings
};

const notificationColors = {
  drive: 'bg-blue-500',
  application: 'bg-green-500',
  interview: 'bg-yellow-500',
  announcement: 'bg-purple-500',
  system: 'bg-gray-500'
};

export function NotificationsPanel() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [filter, setFilter] = useState<'all' | 'unread' | 'read'>('all');

  const filteredNotifications = notifications.filter(notif => {
    if (filter === 'unread') return !notif.read;
    if (filter === 'read') return notif.read;
    return true;
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
    toast.success('Notification marked as read');
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notif => ({ ...notif, read: true }))
    );
    toast.success('All notifications marked as read');
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id));
    toast.success('Notification deleted');
  };

  const deleteAllRead = () => {
    setNotifications(prev => prev.filter(notif => !notif.read));
    toast.success('All read notifications deleted');
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      const mins = Math.floor(diffInHours * 60);
      return `${mins} minute${mins !== 1 ? 's' : ''} ago`;
    } else if (diffInHours < 24) {
      const hours = Math.floor(diffInHours);
      return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    } else if (diffInHours < 48) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="flex items-center gap-2">
            <Bell className="h-6 w-6" />
            Notifications
            {unreadCount > 0 && (
              <Badge className="bg-red-500">{unreadCount}</Badge>
            )}
          </h2>
          <p className="text-muted-foreground mt-2">
            Stay updated with your placement activities
          </p>
        </div>
        <div className="flex gap-2">
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              <CheckCheck className="h-4 w-4 mr-2" />
              Mark All Read
            </Button>
          )}
          {notifications.some(n => n.read) && (
            <Button variant="outline" onClick={deleteAllRead}>
              <Trash2 className="h-4 w-4 mr-2" />
              Clear Read
            </Button>
          )}
        </div>
      </div>

      <Card>
        <CardHeader>
          <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">
                All ({notifications.length})
              </TabsTrigger>
              <TabsTrigger value="unread">
                Unread ({unreadCount})
              </TabsTrigger>
              <TabsTrigger value="read">
                Read ({notifications.length - unreadCount})
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] pr-4">
            <div className="space-y-3">
              {filteredNotifications.length > 0 ? (
                filteredNotifications.map(notif => {
                  const Icon = notificationIcons[notif.type];
                  const colorClass = notificationColors[notif.type];

                  return (
                    <Card
                      key={notif.id}
                      className={`transition-all hover:shadow-md ${
                        !notif.read ? 'border-l-4 border-l-primary bg-blue-50/50' : ''
                      }`}
                    >
                      <CardContent className="p-4">
                        <div className="flex gap-4">
                          <div className={`${colorClass} p-2 rounded-full h-fit`}>
                            <Icon className="h-5 w-5 text-white" />
                          </div>
                          
                          <div className="flex-1 space-y-1">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <h4>{notif.title}</h4>
                                  {!notif.read && (
                                    <Badge variant="secondary" className="text-xs">New</Badge>
                                  )}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {notif.message}
                                </p>
                                <p className="text-xs text-muted-foreground mt-2">
                                  {formatDate(notif.createdAt)}
                                </p>
                              </div>
                              
                              <div className="flex gap-1">
                                {!notif.read && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => markAsRead(notif.id)}
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                )}
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => deleteNotification(notif.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>

                            {notif.actionUrl && (
                              <Button variant="link" className="p-0 h-auto text-sm">
                                View Details →
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              ) : (
                <div className="text-center py-12">
                  <BellOff className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3>No notifications</h3>
                  <p className="text-muted-foreground mt-2">
                    {filter === 'unread' 
                      ? "You're all caught up!" 
                      : filter === 'read'
                      ? "No read notifications"
                      : "You don't have any notifications yet"}
                  </p>
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Notification Preferences
          </CardTitle>
          <CardDescription>
            Choose what notifications you want to receive
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { type: 'drive', label: 'New Placement Drives', description: 'Get notified about new placement opportunities' },
              { type: 'application', label: 'Application Updates', description: 'Status changes in your applications' },
              { type: 'interview', label: 'Interview Schedules', description: 'Interview invitations and reminders' },
              { type: 'announcement', label: 'Announcements', description: 'Important updates from college and recruiters' },
              { type: 'system', label: 'System Notifications', description: 'Account and system related updates' }
            ].map(item => {
              const Icon = notificationIcons[item.type as keyof typeof notificationIcons];
              return (
                <div key={item.type} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Icon className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p>{item.label}</p>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Enable
                  </Button>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
