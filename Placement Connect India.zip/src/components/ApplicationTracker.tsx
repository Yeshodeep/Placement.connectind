import { useState } from 'react';
import { Application } from '../types';
import { mockApplications, mockPlacementDrives } from '../data/mockData';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  CheckCircle2,
  Clock,
  XCircle,
  Calendar,
  FileText,
  Building2,
  MapPin,
  Mail,
  Phone,
  User,
  Download,
  Eye
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { toast } from 'sonner@2.0.3';

const statusConfig = {
  'Applied': { color: 'bg-blue-500', icon: Clock, label: 'Applied', step: 1 },
  'Shortlisted': { color: 'bg-purple-500', icon: CheckCircle2, label: 'Shortlisted', step: 2 },
  'Interview Scheduled': { color: 'bg-yellow-500', icon: Calendar, label: 'Interview', step: 3 },
  'Selected': { color: 'bg-green-500', icon: CheckCircle2, label: 'Selected', step: 4 },
  'Rejected': { color: 'bg-red-500', icon: XCircle, label: 'Rejected', step: 0 },
  'On Hold': { color: 'bg-gray-500', icon: Clock, label: 'On Hold', step: 0 }
};

export function ApplicationTracker({ userRole = 'student' }: { userRole?: 'student' | 'recruiter' }) {
  const [applications, setApplications] = useState<Application[]>(mockApplications);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredApps = filterStatus === 'all' 
    ? applications 
    : applications.filter(app => app.status === filterStatus);

  const getDriveDetails = (driveId: string) => {
    return mockPlacementDrives.find(d => d.id === driveId);
  };

  const getProgressPercentage = (status: string) => {
    const step = statusConfig[status as keyof typeof statusConfig]?.step || 0;
    return step === 0 ? 100 : (step / 4) * 100;
  };

  const handleViewDetails = (app: Application) => {
    setSelectedApp(app);
    setIsDetailsOpen(true);
  };

  const statusCounts = {
    all: applications.length,
    'Applied': applications.filter(a => a.status === 'Applied').length,
    'Shortlisted': applications.filter(a => a.status === 'Shortlisted').length,
    'Interview Scheduled': applications.filter(a => a.status === 'Interview Scheduled').length,
    'Selected': applications.filter(a => a.status === 'Selected').length,
    'Rejected': applications.filter(a => a.status === 'Rejected').length,
  };

  return (
    <div className="space-y-6">
      <div>
        <h2>Application Tracker</h2>
        <p className="text-muted-foreground mt-2">
          Track and manage all your placement applications
        </p>
      </div>

      {/* Status Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card 
          className={`cursor-pointer transition-all ${filterStatus === 'all' ? 'ring-2 ring-primary' : 'hover:shadow-md'}`}
          onClick={() => setFilterStatus('all')}
        >
          <CardHeader className="pb-3">
            <CardDescription>Total</CardDescription>
            <CardTitle className="text-2xl">{statusCounts.all}</CardTitle>
          </CardHeader>
        </Card>

        {Object.entries(statusConfig).filter(([key]) => key !== 'On Hold').map(([status, config]) => (
          <Card 
            key={status}
            className={`cursor-pointer transition-all ${filterStatus === status ? 'ring-2 ring-primary' : 'hover:shadow-md'}`}
            onClick={() => setFilterStatus(status)}
          >
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-2">
                <config.icon className="h-4 w-4" />
                {config.label}
              </CardDescription>
              <CardTitle className="text-2xl">
                {statusCounts[status as keyof typeof statusCounts] || 0}
              </CardTitle>
            </CardHeader>
          </Card>
        ))}
      </div>

      {/* Applications List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>
                {filterStatus === 'all' ? 'All Applications' : `${filterStatus} Applications`}
              </CardTitle>
              <CardDescription>
                {filteredApps.length} application{filteredApps.length !== 1 ? 's' : ''} found
              </CardDescription>
            </div>
            {filterStatus !== 'all' && (
              <Button variant="outline" onClick={() => setFilterStatus('all')}>
                Clear Filter
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredApps.length > 0 ? (
              filteredApps.map(app => {
                const drive = getDriveDetails(app.driveId);
                const config = statusConfig[app.status];
                const Icon = config.icon;

                return (
                  <Card key={app.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1 space-y-3">
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-lg">{drive?.company}</h3>
                                <Badge variant="outline">{app.status}</Badge>
                              </div>
                              <p className="text-muted-foreground">{drive?.position}</p>
                              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  {drive?.city}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-4 w-4" />
                                  Applied: {new Date(app.appliedDate).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Progress Bar */}
                          {app.status !== 'Rejected' && app.status !== 'On Hold' && (
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground">Application Progress</span>
                                <span>{config.step}/4</span>
                              </div>
                              <Progress value={getProgressPercentage(app.status)} />
                              <div className="flex items-center justify-between text-xs text-muted-foreground">
                                <span>Applied</span>
                                <span>Shortlisted</span>
                                <span>Interview</span>
                                <span>Selected</span>
                              </div>
                            </div>
                          )}

                          {app.interviewDate && (
                            <div className="flex items-center gap-2 text-sm bg-yellow-50 text-yellow-800 p-2 rounded">
                              <Calendar className="h-4 w-4" />
                              <span>Interview scheduled on {new Date(app.interviewDate).toLocaleDateString()} at 10:00 AM</span>
                            </div>
                          )}

                          {app.notes && (
                            <div className="text-sm bg-blue-50 text-blue-800 p-2 rounded">
                              <strong>Note:</strong> {app.notes}
                            </div>
                          )}
                        </div>

                        <div className="flex flex-col gap-2">
                          <Button variant="outline" onClick={() => handleViewDetails(app)}>
                            View Details
                          </Button>
                          {app.resumeUrl && (
                            <Button variant="outline" size="sm">
                              <FileText className="h-4 w-4 mr-2" />
                              Resume
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3>No applications found</h3>
                <p className="text-muted-foreground mt-2">
                  {filterStatus === 'all' 
                    ? "You haven't applied to any drives yet" 
                    : `No applications with status "${filterStatus}"`}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Application Details Dialog */}
      {selectedApp && (
        <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Application Details</DialogTitle>
              <DialogDescription>
                Complete information about your application
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {(() => {
                const drive = getDriveDetails(selectedApp.driveId);
                return (
                  <>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="mb-3">Company Information</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                            <span>{drive?.company}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{drive?.location}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>Drive Date: {drive && new Date(drive.date).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="mb-3">Student Information</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span>{selectedApp.studentName}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-muted-foreground" />
                            <span>{selectedApp.studentEmail}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Phone className="h-4 w-4 text-muted-foreground" />
                            <span>{selectedApp.studentPhone}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="mb-3">Application Status</h4>
                      <div className="flex items-center gap-3">
                        <Badge className={statusConfig[selectedApp.status].color}>
                          {selectedApp.status}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          Last updated: {new Date(selectedApp.lastUpdated).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    {selectedApp.interviewDate && (
                      <div className="border-t pt-4">
                        <h4 className="mb-3">Interview Details</h4>
                        <div className="bg-yellow-50 p-3 rounded text-sm">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            <span>Scheduled on: {new Date(selectedApp.interviewDate).toLocaleDateString()} at 10:00 AM</span>
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="border-t pt-4">
                      <h4 className="mb-3">Academic Details</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Branch:</span>
                          <span className="ml-2">{selectedApp.branch}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">CGPA:</span>
                          <span className="ml-2">{selectedApp.cgpa}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Graduation Year:</span>
                          <span className="ml-2">{selectedApp.graduationYear}</span>
                        </div>
                      </div>
                    </div>

                    {selectedApp.notes && (
                      <div className="border-t pt-4">
                        <h4 className="mb-3">Additional Notes</h4>
                        <p className="text-sm text-muted-foreground">{selectedApp.notes}</p>
                      </div>
                    )}

                    {/* Resume Section */}
                    {selectedApp.resumeUrl && (
                      <div className="border-t pt-4">
                        <h4 className="mb-3">Resume</h4>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            className="flex-1"
                            onClick={() => {
                              window.open(selectedApp.resumeUrl, '_blank');
                              toast.success('Opening resume in new tab');
                            }}
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            View Resume
                          </Button>
                          <Button 
                            variant="outline"
                            className="flex-1"
                            onClick={() => {
                              // Simulate download
                              const link = document.createElement('a');
                              link.href = selectedApp.resumeUrl!;
                              link.download = `${selectedApp.studentName.replace(/\s+/g, '_')}_Resume.pdf`;
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                              toast.success('Resume downloaded successfully!');
                            }}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download Resume
                          </Button>
                        </div>
                      </div>
                    )}
                  </>
                );
              })()}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}