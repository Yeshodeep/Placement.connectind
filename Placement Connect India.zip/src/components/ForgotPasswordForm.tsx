import { useState } from 'react';
import { UserRole } from '../types';
import { resetPassword } from '../utils/auth';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { ArrowLeft, KeyRound } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface ForgotPasswordFormProps {
  onBackToLogin: () => void;
}

export function ForgotPasswordForm({ onBackToLogin }: ForgotPasswordFormProps) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('student');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);
  const [tempPassword, setTempPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error('Please enter a valid email address');
      setIsSubmitting(false);
      return;
    }

    const result = resetPassword(email, role);
    
    if (result.success && result.tempPassword) {
      toast.success(result.message);
      setResetSuccess(true);
      setTempPassword(result.tempPassword);
    } else {
      toast.error(result.message);
    }

    setIsSubmitting(false);
  };

  if (resetSuccess) {
    return (
      <Card className="p-8 max-w-md mx-auto">
        <div className="text-center">
          <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <KeyRound className="h-8 w-8 text-green-600" />
          </div>
          <h2 className="text-2xl mb-2">Password Reset Successful!</h2>
          <p className="text-sm text-muted-foreground mb-6">
            Your password has been reset. Please use the temporary password below to login.
          </p>

          <div className="bg-muted p-4 rounded-lg mb-6">
            <p className="text-sm mb-2">Temporary Password:</p>
            <p className="text-lg select-all break-all">
              <strong>{tempPassword}</strong>
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Please change this password after logging in for security.
            </p>
          </div>

          <Button
            onClick={onBackToLogin}
            className="w-full"
          >
            Back to Login
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-8 max-w-md mx-auto">
      <Button
        variant="ghost"
        size="sm"
        onClick={onBackToLogin}
        className="mb-4 gap-2"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Login
      </Button>

      <div className="text-center mb-6">
        <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <KeyRound className="h-8 w-8 text-orange-600" />
        </div>
        <h2 className="text-2xl mb-2">Forgot Password?</h2>
        <p className="text-sm text-muted-foreground">
          Enter your email and role to reset your password
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email Address</Label>
          <Input
            id="email"
            type="email"
            placeholder="your.email@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="role">Account Type</Label>
          <Select value={role} onValueChange={(value) => setRole(value as UserRole)}>
            <SelectTrigger id="role">
              <SelectValue placeholder="Select your role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="student">Student</SelectItem>
              <SelectItem value="recruiter">Recruiter</SelectItem>
              <SelectItem value="hod">College HOD</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button
          type="submit"
          className="w-full"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Resetting Password...' : 'Reset Password'}
        </Button>
      </form>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <p className="text-xs text-blue-800">
          <strong>Note:</strong> A temporary password will be generated and displayed on the next screen. 
          Please save it securely and change it after logging in.
        </p>
      </div>
    </Card>
  );
}
