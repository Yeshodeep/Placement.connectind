import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import {
  FileText,
  Download,
  Eye,
  Plus,
  Trash2,
  User,
  Briefcase,
  GraduationCap,
  Award,
  Code,
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Github,
  X,
  Upload,
  CheckCircle2
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface ResumeData {
  personal: {
    name: string;
    email: string;
    phone: string;
    location: string;
    linkedin?: string;
    github?: string;
    summary: string;
  };
  education: Array<{
    id: string;
    degree: string;
    institution: string;
    year: string;
    cgpa: string;
  }>;
  experience: Array<{
    id: string;
    title: string;
    company: string;
    duration: string;
    description: string;
  }>;
  skills: string[];
  projects: Array<{
    id: string;
    name: string;
    description: string;
    technologies: string;
  }>;
  certifications: Array<{
    id: string;
    name: string;
    issuer: string;
    year: string;
  }>;
}

const initialData: ResumeData = {
  personal: {
    name: 'Rahul Kumar',
    email: 'rahul@example.com',
    phone: '+91 9876543210',
    location: 'Bangalore, Karnataka',
    linkedin: 'linkedin.com/in/rahulkumar',
    github: 'github.com/rahulkumar',
    summary: 'Passionate computer science student with strong problem-solving skills and experience in full-stack development.'
  },
  education: [
    {
      id: 'edu1',
      degree: 'B.Tech in Computer Science',
      institution: 'IIT Delhi',
      year: '2021-2025',
      cgpa: '8.5'
    }
  ],
  experience: [
    {
      id: 'exp1',
      title: 'Software Engineering Intern',
      company: 'Tech Company',
      duration: 'Jun 2024 - Aug 2024',
      description: 'Developed full-stack web applications using React and Node.js'
    }
  ],
  skills: ['React', 'Node.js', 'Python', 'Java', 'SQL', 'AWS'],
  projects: [
    {
      id: 'proj1',
      name: 'E-Commerce Platform',
      description: 'Built a full-stack e-commerce platform with payment integration',
      technologies: 'React, Node.js, MongoDB, Stripe'
    }
  ],
  certifications: [
    {
      id: 'cert1',
      name: 'AWS Certified Developer',
      issuer: 'Amazon Web Services',
      year: '2024'
    }
  ]
};

export function ResumeBuilder() {
  const [resumeData, setResumeData] = useState<ResumeData>(initialData);
  const [activeTab, setActiveTab] = useState('personal');
  const [newSkill, setNewSkill] = useState('');
  const [uploadedResume, setUploadedResume] = useState<File | null>(null);
  const [resumeUrl, setResumeUrl] = useState<string>('https://example.com/resumes/rahul-kumar.pdf');

  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
        setUploadedResume(file);
        // Simulate upload - in real app this would upload to server
        setResumeUrl(`https://example.com/resumes/${file.name}`);
        toast.success('Resume uploaded successfully!', {
          description: `${file.name} is now your active resume.`
        });
      } else {
        toast.error('Invalid file type', {
          description: 'Please upload a PDF file.'
        });
      }
    }
  };

  const handlePersonalChange = (field: string, value: string) => {
    setResumeData(prev => ({
      ...prev,
      personal: { ...prev.personal, [field]: value }
    }));
  };

  const addEducation = () => {
    setResumeData(prev => ({
      ...prev,
      education: [...prev.education, {
        id: `edu${prev.education.length + 1}`,
        degree: '',
        institution: '',
        year: '',
        cgpa: ''
      }]
    }));
  };

  const removeEducation = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.filter(e => e.id !== id)
    }));
  };

  const updateEducation = (id: string, field: string, value: string) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.map(e => 
        e.id === id ? { ...e, [field]: value } : e
      )
    }));
  };

  const addExperience = () => {
    setResumeData(prev => ({
      ...prev,
      experience: [...prev.experience, {
        id: `exp${prev.experience.length + 1}`,
        title: '',
        company: '',
        duration: '',
        description: ''
      }]
    }));
  };

  const removeExperience = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.filter(e => e.id !== id)
    }));
  };

  const updateExperience = (id: string, field: string, value: string) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.map(e => 
        e.id === id ? { ...e, [field]: value } : e
      )
    }));
  };

  const addSkill = () => {
    if (newSkill.trim() && !resumeData.skills.includes(newSkill.trim())) {
      setResumeData(prev => ({
        ...prev,
        skills: [...prev.skills, newSkill.trim()]
      }));
      setNewSkill('');
    }
  };

  const removeSkill = (skill: string) => {
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skill)
    }));
  };

  const addProject = () => {
    setResumeData(prev => ({
      ...prev,
      projects: [...prev.projects, {
        id: `proj${prev.projects.length + 1}`,
        name: '',
        description: '',
        technologies: ''
      }]
    }));
  };

  const removeProject = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.filter(p => p.id !== id)
    }));
  };

  const updateProject = (id: string, field: string, value: string) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.map(p => 
        p.id === id ? { ...p, [field]: value } : p
      )
    }));
  };

  const addCertification = () => {
    setResumeData(prev => ({
      ...prev,
      certifications: [...prev.certifications, {
        id: `cert${prev.certifications.length + 1}`,
        name: '',
        issuer: '',
        year: ''
      }]
    }));
  };

  const removeCertification = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      certifications: prev.certifications.filter(c => c.id !== id)
    }));
  };

  const updateCertification = (id: string, field: string, value: string) => {
    setResumeData(prev => ({
      ...prev,
      certifications: prev.certifications.map(c => 
        c.id === id ? { ...c, [field]: value } : c
      )
    }));
  };

  const handleDownload = () => {
    toast.success('Resume downloaded successfully!');
  };

  const handlePreview = () => {
    toast.success('Opening resume preview...');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="flex items-center gap-2">
            <FileText className="h-6 w-6" />
            Resume Builder
          </h2>
          <p className="text-muted-foreground mt-2">
            Create and customize your professional resume
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handlePreview}>
            <Eye className="h-4 w-4 mr-2" />
            Preview
          </Button>
          <Button onClick={handleDownload}>
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </div>

      {/* Resume Upload Section */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Upload className="h-5 w-5 text-primary" />
                <h3>Upload Your Resume</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Upload an existing resume (PDF only) or build one from scratch below
              </p>
              {resumeUrl && (
                <Alert className="mt-3 bg-white border-green-200">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-sm">
                    Resume uploaded successfully! This will be visible to recruiters and HODs.
                  </AlertDescription>
                </Alert>
              )}
            </div>
            <div className="flex gap-2">
              <label htmlFor="resume-upload">
                <input
                  id="resume-upload"
                  type="file"
                  accept=".pdf"
                  onChange={handleResumeUpload}
                  className="hidden"
                />
                <Button variant="outline" asChild>
                  <span className="cursor-pointer">
                    <Upload className="h-4 w-4 mr-2" />
                    {uploadedResume ? 'Replace Resume' : 'Upload PDF'}
                  </span>
                </Button>
              </label>
              {resumeUrl && (
                <Button variant="outline" onClick={() => window.open(resumeUrl, '_blank')}>
                  <Eye className="h-4 w-4 mr-2" />
                  View
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-[1fr_400px] gap-6">
        {/* Editor */}
        <Card>
          <CardHeader>
            <CardTitle>Build Your Resume</CardTitle>
            <CardDescription>Fill in your details to create a professional resume</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
                <TabsTrigger value="personal">
                  <User className="h-4 w-4 lg:mr-2" />
                  <span className="hidden lg:inline">Personal</span>
                </TabsTrigger>
                <TabsTrigger value="education">
                  <GraduationCap className="h-4 w-4 lg:mr-2" />
                  <span className="hidden lg:inline">Education</span>
                </TabsTrigger>
                <TabsTrigger value="experience">
                  <Briefcase className="h-4 w-4 lg:mr-2" />
                  <span className="hidden lg:inline">Experience</span>
                </TabsTrigger>
                <TabsTrigger value="skills">
                  <Code className="h-4 w-4 lg:mr-2" />
                  <span className="hidden lg:inline">Skills</span>
                </TabsTrigger>
                <TabsTrigger value="projects">
                  <FileText className="h-4 w-4 lg:mr-2" />
                  <span className="hidden lg:inline">Projects</span>
                </TabsTrigger>
                <TabsTrigger value="certifications">
                  <Award className="h-4 w-4 lg:mr-2" />
                  <span className="hidden lg:inline">Certificates</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="personal" className="space-y-4 mt-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <Input
                      value={resumeData.personal.name}
                      onChange={(e) => handlePersonalChange('name', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input
                      type="email"
                      value={resumeData.personal.email}
                      onChange={(e) => handlePersonalChange('email', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone</Label>
                    <Input
                      value={resumeData.personal.phone}
                      onChange={(e) => handlePersonalChange('phone', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Location</Label>
                    <Input
                      value={resumeData.personal.location}
                      onChange={(e) => handlePersonalChange('location', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>LinkedIn (optional)</Label>
                    <Input
                      value={resumeData.personal.linkedin}
                      onChange={(e) => handlePersonalChange('linkedin', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>GitHub (optional)</Label>
                    <Input
                      value={resumeData.personal.github}
                      onChange={(e) => handlePersonalChange('github', e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Professional Summary</Label>
                  <Textarea
                    rows={4}
                    value={resumeData.personal.summary}
                    onChange={(e) => handlePersonalChange('summary', e.target.value)}
                    placeholder="Brief overview of your qualifications and career goals..."
                  />
                </div>
              </TabsContent>

              <TabsContent value="education" className="space-y-4 mt-6">
                {resumeData.education.map((edu, index) => (
                  <Card key={edu.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">Education {index + 1}</CardTitle>
                        {resumeData.education.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeEducation(edu.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        <Label>Degree</Label>
                        <Input
                          value={edu.degree}
                          onChange={(e) => updateEducation(edu.id, 'degree', e.target.value)}
                          placeholder="e.g., B.Tech in Computer Science"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Institution</Label>
                        <Input
                          value={edu.institution}
                          onChange={(e) => updateEducation(edu.id, 'institution', e.target.value)}
                          placeholder="e.g., IIT Delhi"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label>Year</Label>
                          <Input
                            value={edu.year}
                            onChange={(e) => updateEducation(edu.id, 'year', e.target.value)}
                            placeholder="e.g., 2021-2025"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>CGPA/Percentage</Label>
                          <Input
                            value={edu.cgpa}
                            onChange={(e) => updateEducation(edu.id, 'cgpa', e.target.value)}
                            placeholder="e.g., 8.5"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                <Button onClick={addEducation} variant="outline" className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Education
                </Button>
              </TabsContent>

              <TabsContent value="experience" className="space-y-4 mt-6">
                {resumeData.experience.map((exp, index) => (
                  <Card key={exp.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">Experience {index + 1}</CardTitle>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeExperience(exp.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        <Label>Job Title</Label>
                        <Input
                          value={exp.title}
                          onChange={(e) => updateExperience(exp.id, 'title', e.target.value)}
                          placeholder="e.g., Software Engineering Intern"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Company</Label>
                        <Input
                          value={exp.company}
                          onChange={(e) => updateExperience(exp.id, 'company', e.target.value)}
                          placeholder="e.g., Tech Company"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Duration</Label>
                        <Input
                          value={exp.duration}
                          onChange={(e) => updateExperience(exp.id, 'duration', e.target.value)}
                          placeholder="e.g., Jun 2024 - Aug 2024"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea
                          rows={3}
                          value={exp.description}
                          onChange={(e) => updateExperience(exp.id, 'description', e.target.value)}
                          placeholder="Describe your responsibilities and achievements..."
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
                <Button onClick={addExperience} variant="outline" className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Experience
                </Button>
              </TabsContent>

              <TabsContent value="skills" className="space-y-4 mt-6">
                <div className="flex gap-2">
                  <Input
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    placeholder="Add a skill..."
                    onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                  />
                  <Button onClick={addSkill}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {resumeData.skills.map(skill => (
                    <Badge key={skill} variant="secondary" className="gap-2 pr-1">
                      {skill}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-4 w-4 p-0 hover:bg-transparent"
                        onClick={() => removeSkill(skill)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="projects" className="space-y-4 mt-6">
                {resumeData.projects.map((proj, index) => (
                  <Card key={proj.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">Project {index + 1}</CardTitle>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeProject(proj.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        <Label>Project Name</Label>
                        <Input
                          value={proj.name}
                          onChange={(e) => updateProject(proj.id, 'name', e.target.value)}
                          placeholder="e.g., E-Commerce Platform"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea
                          rows={3}
                          value={proj.description}
                          onChange={(e) => updateProject(proj.id, 'description', e.target.value)}
                          placeholder="Describe what you built and the impact..."
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Technologies Used</Label>
                        <Input
                          value={proj.technologies}
                          onChange={(e) => updateProject(proj.id, 'technologies', e.target.value)}
                          placeholder="e.g., React, Node.js, MongoDB"
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
                <Button onClick={addProject} variant="outline" className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Project
                </Button>
              </TabsContent>

              <TabsContent value="certifications" className="space-y-4 mt-6">
                {resumeData.certifications.map((cert, index) => (
                  <Card key={cert.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">Certification {index + 1}</CardTitle>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeCertification(cert.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        <Label>Certification Name</Label>
                        <Input
                          value={cert.name}
                          onChange={(e) => updateCertification(cert.id, 'name', e.target.value)}
                          placeholder="e.g., AWS Certified Developer"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label>Issuing Organization</Label>
                          <Input
                            value={cert.issuer}
                            onChange={(e) => updateCertification(cert.id, 'issuer', e.target.value)}
                            placeholder="e.g., Amazon Web Services"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Year</Label>
                          <Input
                            value={cert.year}
                            onChange={(e) => updateCertification(cert.id, 'year', e.target.value)}
                            placeholder="e.g., 2024"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                <Button onClick={addCertification} variant="outline" className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Certification
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card className="hidden lg:block">
          <CardHeader>
            <CardTitle>Live Preview</CardTitle>
            <CardDescription>See how your resume looks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-white border rounded-lg p-6 space-y-4 text-sm">
              {/* Personal Info */}
              <div className="text-center border-b pb-4">
                <h2 className="text-xl mb-1">{resumeData.personal.name}</h2>
                <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Mail className="h-3 w-3" />
                    {resumeData.personal.email}
                  </span>
                  <span className="flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    {resumeData.personal.phone}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {resumeData.personal.location}
                  </span>
                </div>
              </div>

              {/* Summary */}
              {resumeData.personal.summary && (
                <div>
                  <h3 className="text-sm mb-2">Summary</h3>
                  <p className="text-xs text-muted-foreground">{resumeData.personal.summary}</p>
                </div>
              )}

              {/* Education */}
              {resumeData.education.length > 0 && (
                <div>
                  <h3 className="text-sm mb-2">Education</h3>
                  {resumeData.education.map(edu => (
                    <div key={edu.id} className="mb-2">
                      <p className="text-xs">{edu.degree}</p>
                      <p className="text-xs text-muted-foreground">{edu.institution}</p>
                      <p className="text-xs text-muted-foreground">{edu.year} | CGPA: {edu.cgpa}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Skills */}
              {resumeData.skills.length > 0 && (
                <div>
                  <h3 className="text-sm mb-2">Skills</h3>
                  <div className="flex flex-wrap gap-1">
                    {resumeData.skills.map(skill => (
                      <Badge key={skill} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}