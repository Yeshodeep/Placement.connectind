import { useState } from 'react';
import { UserRole } from '../types';
import { LoginCredentials, login } from '../utils/auth';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { GraduationCap, Building2, UserCheck } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { AuthUser } from '../utils/auth';

interface LoginFormProps {
  role: UserRole;
  onSuccess: (user: AuthUser) => void;
  onSignUpClick: () => void;
  onForgotPasswordClick: () => void;
}

export function LoginForm({ role, onSuccess, onSignUpClick, onForgotPasswordClick }: LoginFormProps) {
  const [credentials, setCredentials] = useState<LoginCredentials>({
    email: '',
    password: '',
    role,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const result = login(credentials);
    
    if (result.success && result.user) {
      toast.success(result.message);
      onSuccess(result.user);
    } else {
      toast.error(result.message);
    }

    setIsSubmitting(false);
  };

  const handleChange = (field: keyof LoginCredentials, value: string) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
  };

  const getRoleIcon = () => {
    switch (role) {
      case 'student':
        return <GraduationCap className="h-8 w-8 text-blue-600" />;
      case 'recruiter':
        return <Building2 className="h-8 w-8 text-purple-600" />;
      case 'hod':
        return <UserCheck className="h-8 w-8 text-green-600" />;
    }
  };

  const getRoleBgColor = () => {
    switch (role) {
      case 'student':
        return 'bg-blue-100';
      case 'recruiter':
        return 'bg-purple-100';
      case 'hod':
        return 'bg-green-100';
    }
  };

  const getRoleTitle = () => {
    switch (role) {
      case 'student':
        return 'Student Login';
      case 'recruiter':
        return 'Recruiter Login';
      case 'hod':
        return 'College HOD Login';
    }
  };

  const getRoleDescription = () => {
    switch (role) {
      case 'student':
        return 'Browse placement drives and apply to opportunities';
      case 'recruiter':
        return 'Post placement drives and manage applications';
      case 'hod':
        return 'Approve drives and monitor student placements';
    }
  };

  return (
    <Card className="p-8 max-w-md mx-auto">
      <div className="text-center mb-6">
        <div className={`${getRoleBgColor()} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
          {getRoleIcon()}
        </div>
        <h2 className="text-2xl mb-2">{getRoleTitle()}</h2>
        <p className="text-sm text-muted-foreground">
          {getRoleDescription()}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email Address</Label>
          <Input
            id="email"
            type="email"
            placeholder="your.email@example.com"
            value={credentials.email}
            onChange={(e) => handleChange('email', e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <Input
            id="password"
            type="password"
            placeholder="Enter your password"
            value={credentials.password}
            onChange={(e) => handleChange('password', e.target.value)}
            required
          />
        </div>

        <div className="flex justify-end">
          <Button
            type="button"
            variant="link"
            size="sm"
            onClick={onForgotPasswordClick}
            className="text-xs px-0"
          >
            Forgot Password?
          </Button>
        </div>

        <Button
          type="submit"
          className="w-full"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Logging in...' : 'Login'}
        </Button>

        <div className="text-center pt-4 border-t">
          <p className="text-sm text-muted-foreground mb-2">
            Don't have an account?
          </p>
          <Button
            type="button"
            variant="outline"
            onClick={onSignUpClick}
            className="w-full"
          >
            Sign Up as {role === 'hod' ? 'HOD' : role.charAt(0).toUpperCase() + role.slice(1)}
          </Button>
        </div>
      </form>
    </Card>
  );
}