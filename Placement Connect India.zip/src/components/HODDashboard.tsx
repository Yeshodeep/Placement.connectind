import { useState } from 'react';
import { PlacementDrive } from '../types';
import { mockPlacementDrives, mockStudentProfiles } from '../data/mockData';
import { PlacementDriveCard } from './PlacementDriveCard';
import { DriveDetailsDialog } from './DriveDetailsDialog';
import { StudentsDirectory } from './StudentsDirectory';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  TrendingUp, 
  Users, 
  Building2,
  GraduationCap,
  UserCheck
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function HODDashboard() {
  const [selectedDrive, setSelectedDrive] = useState<PlacementDrive | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [approvedDrives, setApprovedDrives] = useState<Set<string>>(
    new Set(mockPlacementDrives.filter(d => d.approvedByHOD).map(d => d.id))
  );
  const [rejectedDrives, setRejectedDrives] = useState<Set<string>>(new Set());

  const pendingDrives = mockPlacementDrives.filter(
    d => !approvedDrives.has(d.id) && !rejectedDrives.has(d.id)
  );
  const approvedDrivesList = mockPlacementDrives.filter(d => approvedDrives.has(d.id));
  const rejectedDrivesList = mockPlacementDrives.filter(d => rejectedDrives.has(d.id));

  const handleViewDetails = (drive: PlacementDrive) => {
    setSelectedDrive(drive);
    setIsDetailsOpen(true);
  };

  const handleApprove = (driveId: string) => {
    setApprovedDrives(prev => new Set(prev).add(driveId));
    const drive = mockPlacementDrives.find(d => d.id === driveId);
    toast.success(`Approved: ${drive?.company}`, {
      description: 'Students can now register for this drive.'
    });
  };

  const handleReject = (driveId: string) => {
    setRejectedDrives(prev => new Set(prev).add(driveId));
    const drive = mockPlacementDrives.find(d => d.id === driveId);
    toast.error(`Rejected: ${drive?.company}`, {
      description: 'The recruiter will be notified.'
    });
  };

  const totalStudentsRegistered = approvedDrivesList.reduce(
    (sum, drive) => sum + drive.registeredStudents, 
    0
  );
  const averagePackage = approvedDrivesList.length > 0
    ? approvedDrivesList.reduce((sum, d) => sum + (d.package.min + d.package.max) / 2, 0) / approvedDrivesList.length
    : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1>HOD Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Manage placement drives and monitor student participation
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Pending Approval</CardDescription>
            <CardTitle className="text-3xl">{pendingDrives.length}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-orange-600">
              <Clock className="h-4 w-4" />
              <span>Requires action</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Approved Drives</CardDescription>
            <CardTitle className="text-3xl">{approvedDrives.size}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-green-600">
              <CheckCircle2 className="h-4 w-4" />
              <span>Active opportunities</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Students Registered</CardDescription>
            <CardTitle className="text-3xl">{totalStudentsRegistered}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <GraduationCap className="h-4 w-4" />
              <span>Across all drives</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Avg. Package</CardDescription>
            <CardTitle className="text-3xl">₹{averagePackage.toFixed(1)}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <TrendingUp className="h-4 w-4" />
              <span>LPA offered</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for different views */}
      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList className="flex flex-wrap h-auto">
          <TabsTrigger value="pending">
            <Clock className="h-4 w-4 mr-2" />
            Pending
            {pendingDrives.length > 0 && (
              <Badge variant="secondary" className="ml-2">{pendingDrives.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="approved">
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Approved
          </TabsTrigger>
          <TabsTrigger value="rejected">
            <XCircle className="h-4 w-4 mr-2" />
            Rejected
          </TabsTrigger>
          <TabsTrigger value="all">
            <Building2 className="h-4 w-4 mr-2" />
            All Drives
          </TabsTrigger>
          <TabsTrigger value="students">
            <UserCheck className="h-4 w-4 mr-2" />
            Students
            <Badge variant="secondary" className="ml-2">{mockStudentProfiles.length}</Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          {pendingDrives.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>Drives Pending Approval</CardTitle>
                <CardDescription>
                  Review and approve placement drives for your college
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Company</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Package</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingDrives.map(drive => (
                      <TableRow key={drive.id}>
                        <TableCell>{drive.company}</TableCell>
                        <TableCell>{drive.position}</TableCell>
                        <TableCell>{drive.city}, {drive.state}</TableCell>
                        <TableCell>₹{drive.package.min}-{drive.package.max} LPA</TableCell>
                        <TableCell>{new Date(drive.date).toLocaleDateString('en-IN')}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{drive.type}</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleViewDetails(drive)}
                            >
                              View
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-green-600 hover:text-green-700 hover:border-green-600"
                              onClick={() => handleApprove(drive.id)}
                            >
                              <CheckCircle2 className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 hover:text-red-700 hover:border-red-600"
                              onClick={() => handleReject(drive.id)}
                            >
                              <XCircle className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <CheckCircle2 className="h-12 w-12 mx-auto text-green-500 mb-4" />
                <h3>All caught up!</h3>
                <p className="text-muted-foreground mt-2">
                  No drives pending approval at the moment
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-4">
          {approvedDrivesList.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {approvedDrivesList.map(drive => (
                <PlacementDriveCard
                  key={drive.id}
                  drive={drive}
                  onViewDetails={handleViewDetails}
                  showActions={true}
                  userRole="hod"
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3>No approved drives</h3>
                <p className="text-muted-foreground mt-2">
                  Approved drives will appear here
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="rejected" className="space-y-4">
          {rejectedDrivesList.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {rejectedDrivesList.map(drive => (
                <PlacementDriveCard
                  key={drive.id}
                  drive={drive}
                  onViewDetails={handleViewDetails}
                  showActions={false}
                  userRole="hod"
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <XCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3>No rejected drives</h3>
                <p className="text-muted-foreground mt-2">
                  Rejected drives will appear here
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockPlacementDrives.map(drive => (
              <PlacementDriveCard
                key={drive.id}
                drive={drive}
                onViewDetails={handleViewDetails}
                showActions={true}
                userRole="hod"
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="students" className="space-y-4">
          <StudentsDirectory students={mockStudentProfiles} />
        </TabsContent>
      </Tabs>

      {/* Details Dialog */}
      <DriveDetailsDialog
        drive={selectedDrive}
        open={isDetailsOpen}
        onOpenChange={setIsDetailsOpen}
        userRole="hod"
      />
    </div>
  );
}