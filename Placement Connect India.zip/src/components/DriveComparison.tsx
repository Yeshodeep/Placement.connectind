import { useState } from 'react';
import { PlacementDrive } from '../types';
import { mockPlacementDrives } from '../data/mockData';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { ScrollArea } from './ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  GitCompare,
  Building2,
  MapPin,
  Calendar,
  IndianRupee,
  GraduationCap,
  Users,
  X,
  CheckCircle2,
  XCircle,
  ArrowRight
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function DriveComparison() {
  const [selectedDrives, setSelectedDrives] = useState<string[]>([]);
  const [comparing, setComparing] = useState(false);

  const availableDrives = mockPlacementDrives.filter(d => 
    d.status === 'Open' || d.status === 'Upcoming'
  );

  const toggleDrive = (driveId: string) => {
    if (selectedDrives.includes(driveId)) {
      setSelectedDrives(prev => prev.filter(id => id !== driveId));
    } else {
      if (selectedDrives.length >= 4) {
        toast.error('Maximum 4 drives can be compared');
        return;
      }
      setSelectedDrives(prev => [...prev, driveId]);
    }
  };

  const comparedDrives = selectedDrives
    .map(id => availableDrives.find(d => d.id === id))
    .filter(Boolean) as PlacementDrive[];

  const handleStartComparing = () => {
    if (selectedDrives.length < 2) {
      toast.error('Please select at least 2 drives to compare');
      return;
    }
    setComparing(true);
  };

  const clearAll = () => {
    setSelectedDrives([]);
    setComparing(false);
  };

  const criteriaComparison = [
    {
      label: 'Package Range',
      getValue: (drive: PlacementDrive) => `₹${drive.package.min} - ${drive.package.max} LPA`,
      getBest: (drives: PlacementDrive[]) => {
        const maxPackage = Math.max(...drives.map(d => d.package.max));
        return drives.filter(d => d.package.max === maxPackage).map(d => d.id);
      }
    },
    {
      label: 'Min CGPA Required',
      getValue: (drive: PlacementDrive) => drive.eligibility.minCGPA.toFixed(1),
      getBest: (drives: PlacementDrive[]) => {
        const minCGPA = Math.min(...drives.map(d => d.eligibility.minCGPA));
        return drives.filter(d => d.eligibility.minCGPA === minCGPA).map(d => d.id);
      }
    },
    {
      label: 'Total Seats',
      getValue: (drive: PlacementDrive) => drive.totalSeats.toString(),
      getBest: (drives: PlacementDrive[]) => {
        const maxSeats = Math.max(...drives.map(d => d.totalSeats));
        return drives.filter(d => d.totalSeats === maxSeats).map(d => d.id);
      }
    },
    {
      label: 'Competition',
      getValue: (drive: PlacementDrive) => {
        const ratio = (drive.registeredStudents / drive.totalSeats).toFixed(1);
        return `${ratio}:1`;
      },
      getBest: (drives: PlacementDrive[]) => {
        const minRatio = Math.min(...drives.map(d => d.registeredStudents / d.totalSeats));
        return drives.filter(d => (d.registeredStudents / d.totalSeats) === minRatio).map(d => d.id);
      }
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="flex items-center gap-2">
            <GitCompare className="h-6 w-6" />
            Compare Placement Drives
          </h2>
          <p className="text-muted-foreground mt-2">
            Compare multiple drives side-by-side to make informed decisions
          </p>
        </div>
        {selectedDrives.length > 0 && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={clearAll}>
              Clear All
            </Button>
            {!comparing && (
              <Button onClick={handleStartComparing}>
                Compare ({selectedDrives.length})
              </Button>
            )}
          </div>
        )}
      </div>

      {!comparing ? (
        <Card>
          <CardHeader>
            <CardTitle>Select Drives to Compare</CardTitle>
            <CardDescription>
              Choose 2-4 placement drives for side-by-side comparison
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {availableDrives.map(drive => (
                <Card 
                  key={drive.id}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedDrives.includes(drive.id) ? 'ring-2 ring-primary bg-primary/5' : ''
                  }`}
                  onClick={() => toggleDrive(drive.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <Checkbox 
                        checked={selectedDrives.includes(drive.id)}
                        onCheckedChange={() => toggleDrive(drive.id)}
                      />
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3>{drive.company}</h3>
                            <p className="text-muted-foreground">{drive.position}</p>
                          </div>
                          <Badge variant={drive.status === 'Open' ? 'default' : 'secondary'}>
                            {drive.status}
                          </Badge>
                        </div>
                        
                        <div className="grid md:grid-cols-4 gap-3 text-sm">
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{drive.city}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <IndianRupee className="h-4 w-4 text-muted-foreground" />
                            <span>{drive.package.min}-{drive.package.max} LPA</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>{new Date(drive.date).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>{drive.totalSeats} seats</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Quick Comparison Header */}
          <div className="grid gap-4" style={{ gridTemplateColumns: `250px repeat(${comparedDrives.length}, 1fr)` }}>
            <div></div>
            {comparedDrives.map(drive => (
              <Card key={drive.id} className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute top-2 right-2"
                  onClick={() => toggleDrive(drive.id)}
                >
                  <X className="h-4 w-4" />
                </Button>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg pr-8">{drive.company}</CardTitle>
                  <CardDescription className="line-clamp-2">{drive.position}</CardDescription>
                  <Badge className="w-fit">{drive.status}</Badge>
                </CardHeader>
              </Card>
            ))}
          </div>

          {/* Detailed Comparison */}
          <Card>
            <CardHeader>
              <CardTitle>Detailed Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Basic Information */}
                <div>
                  <h4 className="mb-4">Basic Information</h4>
                  <div className="space-y-3">
                    {[
                      { label: 'Location', icon: MapPin, getValue: (d: PlacementDrive) => `${d.city}, ${d.state}` },
                      { label: 'Drive Type', icon: Building2, getValue: (d: PlacementDrive) => d.type },
                      { label: 'Drive Date', icon: Calendar, getValue: (d: PlacementDrive) => new Date(d.date).toLocaleDateString() },
                      { label: 'Deadline', icon: Calendar, getValue: (d: PlacementDrive) => new Date(d.deadline).toLocaleDateString() },
                    ].map(item => (
                      <div 
                        key={item.label}
                        className="grid gap-4 py-3 border-b last:border-0"
                        style={{ gridTemplateColumns: `250px repeat(${comparedDrives.length}, 1fr)` }}
                      >
                        <div className="flex items-center gap-2">
                          <item.icon className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{item.label}</span>
                        </div>
                        {comparedDrives.map(drive => (
                          <div key={drive.id} className="text-sm">
                            {item.getValue(drive)}
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Key Criteria with Best Highlighting */}
                <div>
                  <h4 className="mb-4">Key Criteria Comparison</h4>
                  <div className="space-y-3">
                    {criteriaComparison.map(criteria => {
                      const bestIds = criteria.getBest(comparedDrives);
                      return (
                        <div 
                          key={criteria.label}
                          className="grid gap-4 py-3 border-b last:border-0"
                          style={{ gridTemplateColumns: `250px repeat(${comparedDrives.length}, 1fr)` }}
                        >
                          <div className="text-sm">{criteria.label}</div>
                          {comparedDrives.map(drive => {
                            const isBest = bestIds.includes(drive.id);
                            return (
                              <div 
                                key={drive.id}
                                className={`text-sm p-2 rounded ${
                                  isBest ? 'bg-green-50 border-2 border-green-500' : ''
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <span>{criteria.getValue(drive)}</span>
                                  {isBest && (
                                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Eligibility */}
                <div>
                  <h4 className="mb-4">Eligibility Criteria</h4>
                  <div className="space-y-3">
                    <div 
                      className="grid gap-4 py-3 border-b"
                      style={{ gridTemplateColumns: `250px repeat(${comparedDrives.length}, 1fr)` }}
                    >
                      <div className="text-sm">Eligible Branches</div>
                      {comparedDrives.map(drive => (
                        <div key={drive.id} className="flex flex-wrap gap-1">
                          {drive.eligibility.branches.map(branch => (
                            <Badge key={branch} variant="outline" className="text-xs">
                              {branch}
                            </Badge>
                          ))}
                        </div>
                      ))}
                    </div>
                    <div 
                      className="grid gap-4 py-3 border-b"
                      style={{ gridTemplateColumns: `250px repeat(${comparedDrives.length}, 1fr)` }}
                    >
                      <div className="text-sm">Graduation Years</div>
                      {comparedDrives.map(drive => (
                        <div key={drive.id} className="text-sm">
                          {drive.eligibility.graduationYear.join(', ')}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Selection Process */}
                <div>
                  <h4 className="mb-4">Selection Process</h4>
                  <div 
                    className="grid gap-4"
                    style={{ gridTemplateColumns: `250px repeat(${comparedDrives.length}, 1fr)` }}
                  >
                    <div className="text-sm">Rounds</div>
                    {comparedDrives.map(drive => (
                      <div key={drive.id} className="space-y-2">
                        {drive.rounds.map((round, idx) => (
                          <div key={idx} className="flex items-center gap-2 text-sm">
                            <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs">
                              {idx + 1}
                            </div>
                            <span>{round}</span>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recommendation */}
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5" />
                Our Recommendation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4">
                Based on the comparison, here are our insights:
              </p>
              <div className="space-y-2">
                {(() => {
                  const highestPackage = comparedDrives.reduce((max, d) => 
                    d.package.max > max.package.max ? d : max
                  );
                  const lowestCompetition = comparedDrives.reduce((min, d) => 
                    (d.registeredStudents / d.totalSeats) < (min.registeredStudents / min.totalSeats) ? d : min
                  );
                  const easiestEligibility = comparedDrives.reduce((min, d) => 
                    d.eligibility.minCGPA < min.eligibility.minCGPA ? d : min
                  );

                  return (
                    <>
                      <div className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5" />
                        <span><strong>{highestPackage.company}</strong> offers the highest package up to ₹{highestPackage.package.max} LPA</span>
                      </div>
                      <div className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5" />
                        <span><strong>{lowestCompetition.company}</strong> has the lowest competition ratio</span>
                      </div>
                      <div className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5" />
                        <span><strong>{easiestEligibility.company}</strong> has the most relaxed CGPA requirement ({easiestEligibility.eligibility.minCGPA})</span>
                      </div>
                    </>
                  );
                })()}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
