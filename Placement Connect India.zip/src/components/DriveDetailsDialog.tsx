import { PlacementDrive } from '../types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { 
  MapPin, 
  Calendar, 
  Users, 
  Briefcase, 
  GraduationCap, 
  IndianRupee,
  Building2,
  CheckCircle2,
  Clock
} from 'lucide-react';

interface DriveDetailsDialogProps {
  drive: PlacementDrive | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onRegister?: (driveId: string) => void;
  userRole?: 'student' | 'recruiter' | 'hod';
}

export function DriveDetailsDialog({ 
  drive, 
  open, 
  onOpenChange, 
  onRegister,
  userRole = 'student'
}: DriveDetailsDialogProps) {
  if (!drive) return null;

  const statusColors = {
    'Open': 'bg-green-500',
    'Closed': 'bg-red-500',
    'Upcoming': 'bg-blue-500',
    'Completed': 'bg-gray-500'
  };

  const isDeadlinePassed = new Date(drive.deadline) < new Date();
  const canRegister = drive.status === 'Open' && !isDeadlinePassed;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-start">
            <div>
              <DialogTitle className="text-2xl">{drive.company}</DialogTitle>
              <DialogDescription className="mt-2 text-lg">
                {drive.position}
              </DialogDescription>
            </div>
            <Badge className={statusColors[drive.status]}>{drive.status}</Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Key Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <MapPin className="h-5 w-5 text-muted-foreground" />
              <div>
                <div className="text-sm text-muted-foreground">Location</div>
                <div>{drive.location}</div>
                <div className="text-sm">{drive.city}, {drive.state}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <IndianRupee className="h-5 w-5 text-muted-foreground" />
              <div>
                <div className="text-sm text-muted-foreground">Package</div>
                <div>
                  {drive.package.min === drive.package.max 
                    ? `₹${drive.package.min} LPA`
                    : `₹${drive.package.min} - ${drive.package.max} LPA`
                  }
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-muted-foreground" />
              <div>
                <div className="text-sm text-muted-foreground">Drive Date</div>
                <div>{new Date(drive.date).toLocaleDateString('en-IN', { 
                  day: 'numeric',
                  month: 'long', 
                  year: 'numeric' 
                })}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-muted-foreground" />
              <div>
                <div className="text-sm text-muted-foreground">Registration Deadline</div>
                <div className={isDeadlinePassed ? 'text-red-500' : ''}>
                  {new Date(drive.deadline).toLocaleDateString('en-IN', { 
                    day: 'numeric',
                    month: 'long', 
                    year: 'numeric' 
                  })}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-muted-foreground" />
              <div>
                <div className="text-sm text-muted-foreground">Seats Available</div>
                <div>{drive.registeredStudents} / {drive.totalSeats} registered</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Briefcase className="h-5 w-5 text-muted-foreground" />
              <div>
                <div className="text-sm text-muted-foreground">Drive Type</div>
                <div>{drive.type}</div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Description */}
          <div>
            <h3 className="flex items-center gap-2 mb-3">
              <Building2 className="h-5 w-5" />
              About the Role
            </h3>
            <p className="text-muted-foreground">{drive.description}</p>
          </div>

          <Separator />

          {/* Eligibility */}
          <div>
            <h3 className="flex items-center gap-2 mb-3">
              <GraduationCap className="h-5 w-5" />
              Eligibility Criteria
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <div className="text-sm text-muted-foreground mb-1">Degrees</div>
                <div className="flex flex-wrap gap-2">
                  {drive.eligibility.degree.map(deg => (
                    <Badge key={deg} variant="secondary">{deg}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-1">Branches</div>
                <div className="flex flex-wrap gap-2">
                  {drive.eligibility.branches.map(branch => (
                    <Badge key={branch} variant="secondary">{branch}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-1">Minimum CGPA</div>
                <div>{drive.eligibility.minCGPA}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-1">Graduation Year</div>
                <div>{drive.eligibility.graduationYear.join(', ')}</div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Requirements */}
          <div>
            <h3 className="flex items-center gap-2 mb-3">
              <CheckCircle2 className="h-5 w-5" />
              Requirements
            </h3>
            <ul className="space-y-2">
              {drive.requirements.map((req, index) => (
                <li key={index} className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-500 mt-1 flex-shrink-0" />
                  <span className="text-muted-foreground">{req}</span>
                </li>
              ))}
            </ul>
          </div>

          <Separator />

          {/* Selection Process */}
          <div>
            <h3 className="mb-3">Selection Process</h3>
            <div className="flex flex-wrap gap-2">
              {drive.rounds.map((round, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Badge variant="outline" className="text-sm py-1 px-3">
                    Round {index + 1}: {round}
                  </Badge>
                  {index < drive.rounds.length - 1 && (
                    <span className="text-muted-foreground">→</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Participating Colleges */}
          <div>
            <h3 className="mb-3">Participating Colleges</h3>
            <div className="flex flex-wrap gap-2">
              {drive.colleges.map((college, index) => (
                <Badge key={index} variant="secondary">{college}</Badge>
              ))}
            </div>
          </div>

          <Separator />

          {/* Posted By */}
          <div className="text-sm text-muted-foreground">
            Posted by {drive.postedBy} on {new Date(drive.postedDate).toLocaleDateString('en-IN')}
          </div>

          {/* Action Buttons */}
          {userRole === 'student' && onRegister && canRegister && (
            <div className="flex gap-3 pt-4">
              <Button 
                className="flex-1"
                onClick={() => {
                  onRegister(drive.id);
                  onOpenChange(false);
                }}
              >
                Register for this Drive
              </Button>
            </div>
          )}

          {isDeadlinePassed && (
            <div className="bg-red-50 border border-red-200 rounded-md p-3 text-red-700 text-center">
              Registration deadline has passed
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
