import { PlacementDrive } from '../types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { MapPin, Calendar, Users, Briefcase, GraduationCap, IndianRupee } from 'lucide-react';

interface PlacementDriveCardProps {
  drive: PlacementDrive;
  onViewDetails: (drive: PlacementDrive) => void;
  onRegister?: (driveId: string) => void;
  showActions?: boolean;
  userRole?: 'student' | 'recruiter' | 'hod';
}

export function PlacementDriveCard({ 
  drive, 
  onViewDetails, 
  onRegister, 
  showActions = true,
  userRole = 'student'
}: PlacementDriveCardProps) {
  const statusColors = {
    'Open': 'bg-green-500',
    'Closed': 'bg-red-500',
    'Upcoming': 'bg-blue-500',
    'Completed': 'bg-gray-500'
  };

  const typeColors = {
    'On-Campus': 'bg-purple-500',
    'Off-Campus': 'bg-orange-500',
    'Pool Campus': 'bg-cyan-500'
  };

  const isDeadlinePassed = new Date(drive.deadline) < new Date();
  const canRegister = drive.status === 'Open' && !isDeadlinePassed;

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle>{drive.company}</CardTitle>
            <CardDescription className="mt-1">{drive.position}</CardDescription>
          </div>
          <div className="flex flex-col gap-2 items-end">
            <Badge className={statusColors[drive.status]}>{drive.status}</Badge>
            <Badge variant="outline" className={typeColors[drive.type]}>
              {drive.type}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>{drive.city}, {drive.state}</span>
          </div>
          
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>Drive Date: {new Date(drive.date).toLocaleDateString('en-IN')}</span>
          </div>

          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span className={isDeadlinePassed ? 'text-red-500' : ''}>
              Deadline: {new Date(drive.deadline).toLocaleDateString('en-IN')}
            </span>
          </div>

          <div className="flex items-center gap-2 text-muted-foreground">
            <IndianRupee className="h-4 w-4" />
            <span>
              {drive.package.min === drive.package.max 
                ? `₹${drive.package.min} LPA`
                : `₹${drive.package.min} - ${drive.package.max} LPA`
              }
            </span>
          </div>

          <div className="flex items-center gap-2 text-muted-foreground">
            <GraduationCap className="h-4 w-4" />
            <span>Min CGPA: {drive.eligibility.minCGPA}</span>
          </div>

          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{drive.registeredStudents} / {drive.totalSeats} registered</span>
          </div>

          <div className="flex items-center gap-2 text-muted-foreground">
            <Briefcase className="h-4 w-4" />
            <div className="flex flex-wrap gap-1">
              {drive.eligibility.branches.slice(0, 4).map(branch => (
                <Badge key={branch} variant="secondary" className="text-xs">
                  {branch}
                </Badge>
              ))}
              {drive.eligibility.branches.length > 4 && (
                <Badge variant="secondary" className="text-xs">
                  +{drive.eligibility.branches.length - 4} more
                </Badge>
              )}
            </div>
          </div>

          {userRole === 'hod' && !drive.approvedByHOD && (
            <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">
              Pending Approval
            </Badge>
          )}

          {showActions && (
            <div className="flex gap-2 mt-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => onViewDetails(drive)}
              >
                View Details
              </Button>
              {userRole === 'student' && onRegister && canRegister && (
                <Button 
                  className="flex-1"
                  onClick={() => onRegister(drive.id)}
                >
                  Register
                </Button>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
