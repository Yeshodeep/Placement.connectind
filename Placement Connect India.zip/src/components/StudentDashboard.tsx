import { useState } from 'react';
import { PlacementDrive } from '../types';
import { mockPlacementDrives, indianCities, branches, mockHODProfiles } from '../data/mockData';
import { PlacementDriveCard } from './PlacementDriveCard';
import { DriveDetailsDialog } from './DriveDetailsDialog';
import { SubscriptionDialog } from './SubscriptionDialog';
import { MapView } from './MapView';
import { ApplicationTracker } from './ApplicationTracker';
import { NotificationsPanel } from './NotificationsPanel';
import { DocumentManager } from './DocumentManager';
import { MessagingCenter } from './MessagingCenter';
import { AnnouncementsBoard } from './AnnouncementsBoard';
import { DriveComparison } from './DriveComparison';
import { ResumeBuilder } from './ResumeBuilder';
import { AnalyticsDashboard } from './AnalyticsDashboard';
import { HODInfo } from './HODInfo';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from './ui/select';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent } from './ui/card';
import { Search, Filter, MapPin, Briefcase, Calendar, X, Crown, Map, Grid, FileText, Bell, MessageSquare, Megaphone, GitCompare, BarChart, FileUp, UserCheck } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function StudentDashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [selectedBranch, setSelectedBranch] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedDrive, setSelectedDrive] = useState<PlacementDrive | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [registeredDrives, setRegisteredDrives] = useState<Set<string>>(new Set());
  const [isSubscriptionOpen, setIsSubscriptionOpen] = useState(false);
  const [hasSubscription, setHasSubscription] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');

  const filteredDrives = mockPlacementDrives.filter(drive => {
    const matchesSearch = 
      drive.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      drive.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      drive.city.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCity = selectedCity === 'all' || drive.city === selectedCity;
    const matchesBranch = selectedBranch === 'all' || 
      drive.eligibility.branches.includes(selectedBranch);
    const matchesStatus = selectedStatus === 'all' || drive.status === selectedStatus;

    return matchesSearch && matchesCity && matchesBranch && matchesStatus;
  });

  const handleViewDetails = (drive: PlacementDrive) => {
    setSelectedDrive(drive);
    setIsDetailsOpen(true);
  };

  const handleRegister = (driveId: string) => {
    // Check subscription for premium drives
    if (!hasSubscription && registeredDrives.size >= 2) {
      toast.error('Subscription Required', {
        description: 'Upgrade to premium to register for unlimited drives.'
      });
      setIsSubscriptionOpen(true);
      return;
    }

    setRegisteredDrives(prev => new Set(prev).add(driveId));
    const drive = mockPlacementDrives.find(d => d.id === driveId);
    toast.success(`Successfully registered for ${drive?.company}!`, {
      description: 'You will receive further details via email.'
    });
  };

  const handleSubscribe = (plan: 'monthly' | 'annual') => {
    setHasSubscription(true);
    toast.success('Welcome to Premium!', {
      description: 'You now have unlimited access to all features.'
    });
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCity('all');
    setSelectedBranch('all');
    setSelectedStatus('all');
  };

  const activeFiltersCount = 
    (selectedCity !== 'all' ? 1 : 0) +
    (selectedBranch !== 'all' ? 1 : 0) +
    (selectedStatus !== 'all' ? 1 : 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1>Student Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Discover placements, track applications, and manage your career journey
          </p>
        </div>
        {!hasSubscription && (
          <Button 
            variant="outline" 
            className="gap-2 border-yellow-500 text-yellow-700 hover:bg-yellow-50"
            onClick={() => setIsSubscriptionOpen(true)}
          >
            <Crown className="h-4 w-4" />
            Upgrade to Premium
          </Button>
        )}
        {hasSubscription && (
          <Badge className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white px-4 py-2">
            <Crown className="h-4 w-4 mr-2" />
            Premium Member
          </Badge>
        )}
      </div>

      {/* Main Tabs */}
      <Tabs defaultValue="drives" className="space-y-6">
        <TabsList className="flex flex-wrap h-auto">
          <TabsTrigger value="drives">
            <Briefcase className="h-4 w-4 mr-2" />
            Drives
          </TabsTrigger>
          <TabsTrigger value="applications">
            <FileText className="h-4 w-4 mr-2" />
            Applications
          </TabsTrigger>
          <TabsTrigger value="hod">
            <UserCheck className="h-4 w-4 mr-2" />
            My HOD
          </TabsTrigger>
          <TabsTrigger value="compare">
            <GitCompare className="h-4 w-4 mr-2" />
            Compare
          </TabsTrigger>
          <TabsTrigger value="resume">
            <FileUp className="h-4 w-4 mr-2" />
            Resume
          </TabsTrigger>
          <TabsTrigger value="documents">
            Documents
          </TabsTrigger>
          <TabsTrigger value="messages">
            Messages
          </TabsTrigger>
          <TabsTrigger value="notifications">
            Notifications
          </TabsTrigger>
          <TabsTrigger value="announcements">
            Announcements
          </TabsTrigger>
          <TabsTrigger value="analytics">
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="drives" className="space-y-6">
          {/* Free tier limitation banner */}
          {!hasSubscription && registeredDrives.size > 0 && (
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm">
                      <strong>Free Plan:</strong> You've registered for {registeredDrives.size}/2 drives. 
                      Upgrade to premium for unlimited registrations!
                    </p>
                  </div>
                  <Button 
                    size="sm" 
                    onClick={() => setIsSubscriptionOpen(true)}
                    className="gap-2"
                  >
                    <Crown className="h-4 w-4" />
                    Upgrade Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by company, position, or location..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex flex-wrap gap-3">
          <div className="flex-1 min-w-[200px]">
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <SelectValue placeholder="City" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cities</SelectItem>
                {indianCities.map(city => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1 min-w-[200px]">
            <Select value={selectedBranch} onValueChange={setSelectedBranch}>
              <SelectTrigger>
                <div className="flex items-center gap-2">
                  <Briefcase className="h-4 w-4" />
                  <SelectValue placeholder="Branch" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                {branches.map(branch => (
                  <SelectItem key={branch} value={branch}>{branch}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1 min-w-[200px]">
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <SelectValue placeholder="Status" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Open">Open</SelectItem>
                <SelectItem value="Upcoming">Upcoming</SelectItem>
                <SelectItem value="Closed">Closed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {activeFiltersCount > 0 && (
            <Button 
              variant="outline" 
              onClick={clearFilters}
              className="gap-2"
            >
              <X className="h-4 w-4" />
              Clear Filters
              <Badge variant="secondary" className="ml-1">
                {activeFiltersCount}
              </Badge>
            </Button>
          )}
        </div>
      </div>

      {/* View Toggle and Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-muted-foreground">
          {filteredDrives.length} placement {filteredDrives.length === 1 ? 'drive' : 'drives'} found
        </p>
        <div className="flex items-center gap-3">
          {registeredDrives.size > 0 && (
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
              {registeredDrives.size} Registered
            </Badge>
          )}
          <div className="flex gap-1 border rounded-lg p-1">
            <Button
              variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grid')}
              className="gap-2"
            >
              <Grid className="h-4 w-4" />
              Grid
            </Button>
            <Button
              variant={viewMode === 'map' ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('map')}
              className="gap-2"
            >
              <Map className="h-4 w-4" />
              Map
            </Button>
          </div>
        </div>
      </div>

      {/* Drives Grid or Map View */}
      {viewMode === 'grid' ? (
        filteredDrives.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDrives.map(drive => (
              <PlacementDriveCard
                key={drive.id}
                drive={drive}
                onViewDetails={handleViewDetails}
                onRegister={handleRegister}
                userRole="student"
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-muted/50 rounded-lg">
            <Filter className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3>No placement drives found</h3>
            <p className="text-muted-foreground mt-2">
              Try adjusting your search or filters
            </p>
          </div>
        )
      ) : (
        <MapView 
          drives={filteredDrives} 
          onDriveSelect={handleViewDetails}
        />
      )}

        </TabsContent>

        <TabsContent value="applications">
          <ApplicationTracker userRole="student" />
        </TabsContent>

        <TabsContent value="hod">
          <HODInfo hodProfiles={mockHODProfiles} />
        </TabsContent>

        <TabsContent value="compare">
          <DriveComparison />
        </TabsContent>

        <TabsContent value="resume">
          <ResumeBuilder />
        </TabsContent>

        <TabsContent value="documents">
          <DocumentManager />
        </TabsContent>

        <TabsContent value="messages">
          <MessagingCenter userRole="student" />
        </TabsContent>

        <TabsContent value="notifications">
          <NotificationsPanel />
        </TabsContent>

        <TabsContent value="announcements">
          <AnnouncementsBoard userRole="student" />
        </TabsContent>

        <TabsContent value="analytics">
          <AnalyticsDashboard />
        </TabsContent>
      </Tabs>

      {/* Details Dialog */}
      <DriveDetailsDialog
        drive={selectedDrive}
        open={isDetailsOpen}
        onOpenChange={setIsDetailsOpen}
        onRegister={handleRegister}
        userRole="student"
      />

      {/* Subscription Dialog */}
      <SubscriptionDialog
        open={isSubscriptionOpen}
        onOpenChange={setIsSubscriptionOpen}
        userRole="student"
        onSubscribe={handleSubscribe}
      />
    </div>
  );
}