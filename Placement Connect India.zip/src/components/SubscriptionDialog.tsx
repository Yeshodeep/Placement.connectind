import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Check, Crown, Sparkles, Zap, ExternalLink } from 'lucide-react';
import { UserRole } from '../types';
import { toast } from 'sonner@2.0.3';
import { RAZORPAY_PAYMENT_LINKS } from '../config/razorpay';

interface SubscriptionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userRole: UserRole;
  onSubscribe?: (plan: 'monthly' | 'annual') => void;
}

export function SubscriptionDialog({ 
  open, 
  onOpenChange, 
  userRole,
  onSubscribe 
}: SubscriptionDialogProps) {
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'annual' | null>(null);

  const handleSubscribe = (plan: 'monthly' | 'annual') => {
    // Get the payment link based on user role and plan
    let paymentLink = '';
    
    if (userRole === 'student' && plan === 'monthly') {
      paymentLink = RAZORPAY_PAYMENT_LINKS.student_monthly;
    } else if (userRole === 'recruiter' && plan === 'annual') {
      paymentLink = RAZORPAY_PAYMENT_LINKS.recruiter_annual;
    }

    // Check if payment link is configured
    if (!paymentLink || paymentLink.includes('PASTE_YOUR')) {
      toast.error('Payment Not Configured', {
        description: 'Please configure Razorpay payment links in /config/razorpay.ts'
      });
      return;
    }

    // Open Razorpay payment link in new tab
    window.open(paymentLink, '_blank');
    
    toast.info('Payment Link Opened', {
      description: 'Complete your payment on Razorpay. After payment, contact support to activate your subscription.'
    });
    
    // Note: In production with backend, you'd wait for webhook confirmation
    // For now, this is manual verification
  };

  const studentFeatures = [
    'Access to all placement drives',
    'Real-time notifications',
    'Application tracking',
    'Company insights',
    'Resume builder tools',
    'Interview preparation resources',
    'Priority customer support',
    'No advertisements'
  ];

  const recruiterFeatures = [
    'Post unlimited placement drives',
    'Advanced analytics dashboard',
    'Bulk student data export',
    'Priority drive listings',
    'Dedicated account manager',
    'Custom branding options',
    'API access for integrations',
    'Premium support 24/7'
  ];

  const features = userRole === 'student' ? studentFeatures : recruiterFeatures;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Crown className="h-6 w-6 text-yellow-500" />
            <DialogTitle className="text-2xl">Upgrade to Premium</DialogTitle>
          </div>
          <DialogDescription>
            {userRole === 'student' 
              ? 'Get unlimited access to all placement opportunities and premium features'
              : 'Post unlimited drives and connect with thousands of talented students'
            }
          </DialogDescription>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          {userRole === 'student' ? (
            <>
              {/* Student Monthly Plan */}
              <Card className="border-2 hover:border-primary transition-colors">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Sparkles className="h-5 w-5 text-blue-500" />
                        Monthly Plan
                      </CardTitle>
                      <CardDescription className="mt-2">Perfect for active job seekers</CardDescription>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl">₹10</span>
                      <span className="text-muted-foreground">/month</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">Billed monthly</p>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-3">
                    {features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full" 
                    onClick={() => handleSubscribe('monthly')}
                  >
                    Pay with Razorpay
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>

              {/* Free Plan for Reference */}
              <Card className="border-2 border-muted">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    Free Plan
                    <Badge variant="secondary">Current</Badge>
                  </CardTitle>
                  <CardDescription className="mt-2">Limited access to basic features</CardDescription>
                  <div className="mt-4">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl">₹0</span>
                      <span className="text-muted-foreground">/forever</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
                      <span>View up to 5 drives per day</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
                      <span>Basic search filters</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
                      <span>Email notifications</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
                      <span>Standard support</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </>
          ) : (
            <>
              {/* Recruiter Annual Plan */}
              <Card className="border-2 border-primary relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-3 py-1 text-xs">
                  RECOMMENDED
                </div>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-yellow-500" />
                    Annual Plan
                  </CardTitle>
                  <CardDescription className="mt-2">Best value for serious recruiters</CardDescription>
                  <div className="mt-4">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl">₹6,999</span>
                      <span className="text-muted-foreground">/year</span>
                    </div>
                    <p className="text-sm text-green-600 mt-1">Save ₹1,389 vs monthly</p>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-3">
                    {features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full" 
                    size="lg"
                    onClick={() => handleSubscribe('annual')}
                  >
                    Pay with Razorpay
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                  <p className="text-xs text-center text-muted-foreground">
                    7-day money-back guarantee
                  </p>
                </CardContent>
              </Card>

              {/* Free Trial */}
              <Card className="border-2 border-muted">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    Free Trial
                    <Badge variant="secondary">Current</Badge>
                  </CardTitle>
                  <CardDescription className="mt-2">Try before you subscribe</CardDescription>
                  <div className="mt-4">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl">₹0</span>
                      <span className="text-muted-foreground">/14 days</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
                      <span>Post up to 2 drives</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
                      <span>Basic analytics</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
                      <span>Email support</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
                      <span>Standard listing priority</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <div className="flex items-start gap-3">
            <Sparkles className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="mb-2">
                <strong>Secure Payment:</strong> All transactions are encrypted and secure. 
                We accept UPI, Credit/Debit Cards, Net Banking, and Wallets.
              </p>
              <p className="text-muted-foreground text-xs">
                By subscribing, you agree to our Terms of Service and Privacy Policy. 
                Cancel anytime from your account settings.
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
