import { useState } from 'react';
import { Announcement } from '../types';
import { mockAnnouncements } from '../data/mockData';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Megaphone,
  Pin,
  PinOff,
  Calendar,
  User,
  AlertTriangle,
  Info,
  PartyPopper,
  Bell
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

const announcementIcons = {
  general: Info,
  urgent: AlertTriangle,
  event: PartyPopper,
  update: Bell
};

const announcementColors = {
  general: 'bg-blue-500',
  urgent: 'bg-red-500',
  event: 'bg-purple-500',
  update: 'bg-green-500'
};

export function AnnouncementsBoard({ userRole = 'student' }: { userRole?: 'student' | 'recruiter' | 'hod' }) {
  const [announcements, setAnnouncements] = useState<Announcement[]>(mockAnnouncements);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pinned' | 'recent'>('all');

  const canPost = userRole === 'hod' || userRole === 'recruiter';

  const filteredAnnouncements = announcements
    .filter(ann => {
      if (filter === 'pinned') return ann.isPinned;
      if (filter === 'recent') {
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return new Date(ann.createdAt) > weekAgo;
      }
      return true;
    })
    .filter(ann => ann.targetAudience.includes(userRole))
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  const handleCreateAnnouncement = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newAnnouncement: Announcement = {
      id: `ann${announcements.length + 1}`,
      authorId: userRole === 'hod' ? 'hod1' : 'rec1',
      authorName: userRole === 'hod' ? 'Dr. Ramesh Kumar' : 'TCS HR Team',
      authorRole: userRole,
      title: formData.get('title') as string,
      content: formData.get('content') as string,
      type: formData.get('type') as Announcement['type'],
      targetAudience: (formData.get('audience') as string).split(',') as any,
      createdAt: new Date().toISOString(),
      isPinned: false
    };

    setAnnouncements(prev => [newAnnouncement, ...prev]);
    setIsCreateOpen(false);
    toast.success('Announcement posted successfully!');
  };

  const togglePin = (id: string) => {
    setAnnouncements(prev =>
      prev.map(ann =>
        ann.id === id ? { ...ann, isPinned: !ann.isPinned } : ann
      )
    );
    toast.success('Announcement updated');
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      const hours = Math.floor(diffInHours);
      return hours === 0 ? 'Just now' : `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    } else if (diffInHours < 48) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });
    }
  };

  const isExpired = (ann: Announcement) => {
    return ann.expiresAt && new Date(ann.expiresAt) < new Date();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="flex items-center gap-2">
            <Megaphone className="h-6 w-6" />
            Announcements
          </h2>
          <p className="text-muted-foreground mt-2">
            Important updates and notifications from college and recruiters
          </p>
        </div>
        {canPost && (
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Megaphone className="h-4 w-4" />
                Post Announcement
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Post New Announcement</DialogTitle>
                <DialogDescription>
                  Share important information with students and faculty
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreateAnnouncement} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input 
                    id="title" 
                    name="title"
                    placeholder="Enter announcement title"
                    required 
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">Content</Label>
                  <Textarea 
                    id="content" 
                    name="content"
                    placeholder="Write your announcement..."
                    rows={6}
                    required 
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Type</Label>
                    <Select name="type" defaultValue="general" required>
                      <SelectTrigger id="type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                        <SelectItem value="event">Event</SelectItem>
                        <SelectItem value="update">Update</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="audience">Target Audience</Label>
                    <Select name="audience" defaultValue="student" required>
                      <SelectTrigger id="audience">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="student">Students Only</SelectItem>
                        <SelectItem value="recruiter">Recruiters Only</SelectItem>
                        <SelectItem value="student,recruiter">Students & Recruiters</SelectItem>
                        <SelectItem value="student,recruiter,hod">Everyone</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button type="button" variant="outline" className="flex-1" onClick={() => setIsCreateOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" className="flex-1">
                    Post Announcement
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <Card>
        <CardHeader>
          <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pinned">
                <Pin className="h-4 w-4 mr-2" />
                Pinned
              </TabsTrigger>
              <TabsTrigger value="recent">Recent</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredAnnouncements.length > 0 ? (
              filteredAnnouncements.map(ann => {
                const Icon = announcementIcons[ann.type];
                const colorClass = announcementColors[ann.type];
                const expired = isExpired(ann);

                return (
                  <Card 
                    key={ann.id} 
                    className={`transition-all hover:shadow-md ${
                      ann.isPinned ? 'border-l-4 border-l-yellow-500 bg-yellow-50/50' : ''
                    } ${expired ? 'opacity-60' : ''}`}
                  >
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex gap-3 flex-1">
                            <div className={`${colorClass} p-2 rounded h-fit`}>
                              <Icon className="h-5 w-5 text-white" />
                            </div>
                            
                            <div className="flex-1">
                              <div className="flex items-start gap-2 mb-2">
                                <h3>{ann.title}</h3>
                                {ann.isPinned && (
                                  <Badge className="bg-yellow-500">
                                    <Pin className="h-3 w-3 mr-1" />
                                    Pinned
                                  </Badge>
                                )}
                                {expired && (
                                  <Badge variant="outline" className="text-muted-foreground">
                                    Expired
                                  </Badge>
                                )}
                              </div>
                              
                              <p className="text-muted-foreground mb-3">{ann.content}</p>
                              
                              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                                <div className="flex items-center gap-1">
                                  <User className="h-4 w-4" />
                                  <span>{ann.authorName}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Calendar className="h-4 w-4" />
                                  <span>{formatDate(ann.createdAt)}</span>
                                </div>
                                <Badge variant="outline" className="capitalize">
                                  {ann.type}
                                </Badge>
                                {ann.expiresAt && !expired && (
                                  <Badge variant="outline" className="text-orange-600">
                                    Expires: {new Date(ann.expiresAt).toLocaleDateString()}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>

                          {canPost && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => togglePin(ann.id)}
                            >
                              {ann.isPinned ? (
                                <PinOff className="h-4 w-4" />
                              ) : (
                                <Pin className="h-4 w-4" />
                              )}
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <div className="text-center py-12">
                <Megaphone className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3>No announcements</h3>
                <p className="text-muted-foreground mt-2">
                  {filter === 'pinned' 
                    ? 'No pinned announcements' 
                    : filter === 'recent'
                    ? 'No announcements in the last 7 days'
                    : 'No announcements available'}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Total Announcements</CardDescription>
            <CardTitle className="text-3xl">{announcements.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <Pin className="h-4 w-4" />
              Pinned
            </CardDescription>
            <CardTitle className="text-3xl">
              {announcements.filter(a => a.isPinned).length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Urgent
            </CardDescription>
            <CardTitle className="text-3xl">
              {announcements.filter(a => a.type === 'urgent').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <PartyPopper className="h-4 w-4" />
              Events
            </CardDescription>
            <CardTitle className="text-3xl">
              {announcements.filter(a => a.type === 'event').length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
}
