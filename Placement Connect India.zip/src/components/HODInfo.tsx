import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Mail, Phone, MapPin, Clock, GraduationCap, Award, Users, TrendingUp } from 'lucide-react';
import { HODProfile } from '../types';

interface HODInfoProps {
  hod?: HODProfile;
  hodProfiles?: HODProfile[];
}

export function HODInfo({ hod, hodProfiles }: HODInfoProps) {
  // Use the first HOD from profiles if hod is not provided
  const selectedHOD = hod || (hodProfiles && hodProfiles.length > 0 ? hodProfiles[0] : null);

  if (!selectedHOD) {
    return (
      <Card className="p-12 text-center">
        <p className="text-muted-foreground">No HOD information available</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Profile Card */}
      <Card className="p-6">
        <div className="flex items-start gap-6">
          {selectedHOD.photo && (
            <img 
              src={selectedHOD.photo} 
              alt={selectedHOD.name}
              className="w-24 h-24 rounded-full object-cover border-2 border-primary"
            />
          )}
          <div className="flex-1">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h2 className="text-2xl mb-1">{selectedHOD.name}</h2>
                <p className="text-muted-foreground">{selectedHOD.designation}</p>
              </div>
              <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                {selectedHOD.experience} Years Experience
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground mb-4">
              <GraduationCap className="h-4 w-4" />
              <span>{selectedHOD.department}</span>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* College Information */}
        <Card className="p-6">
          <h3 className="mb-4 flex items-center gap-2">
            <Award className="h-5 w-5 text-primary" />
            College Information
          </h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              {selectedHOD.collegeLogo && (
                <img 
                  src={selectedHOD.collegeLogo} 
                  alt={selectedHOD.college}
                  className="w-12 h-12 object-contain"
                />
              )}
              <div>
                <p className="text-sm text-muted-foreground">Institution</p>
                <p>{selectedHOD.college}</p>
              </div>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Department</p>
              <p>{selectedHOD.department}</p>
            </div>
          </div>
        </Card>

        {/* Contact Information */}
        <Card className="p-6">
          <h3 className="mb-4">Contact Details</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-sm">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <a href={`mailto:${selectedHOD.email}`} className="text-blue-600 hover:underline">
                {selectedHOD.email}
              </a>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <a href={`tel:${selectedHOD.phone}`} className="hover:underline">
                {selectedHOD.phone}
              </a>
            </div>
            <div className="flex items-start gap-3 text-sm">
              <MapPin className="h-4 w-4 text-muted-foreground mt-1" />
              <span>{selectedHOD.officeAddress}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span>{selectedHOD.officeHours}</span>
            </div>
          </div>
        </Card>

        {/* Qualifications */}
        <Card className="p-6">
          <h3 className="mb-4">Qualifications</h3>
          <ul className="space-y-2">
            {selectedHOD.qualifications.map((qual, index) => (
              <li key={index} className="text-sm flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>{qual}</span>
              </li>
            ))}
          </ul>
        </Card>

        {/* Specialization */}
        <Card className="p-6">
          <h3 className="mb-4">Areas of Specialization</h3>
          <div className="flex flex-wrap gap-2">
            {selectedHOD.specialization.map((spec, index) => (
              <Badge key={index} variant="outline">
                {spec}
              </Badge>
            ))}
          </div>
        </Card>
      </div>

      {/* Placement Statistics */}
      <Card className="p-6">
        <h3 className="mb-4">Department Placement Statistics</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Users className="h-8 w-8 text-blue-600" />
            </div>
            <p className="text-3xl mb-1">{selectedHOD.totalStudents}</p>
            <p className="text-sm text-muted-foreground">Total Students</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Award className="h-8 w-8 text-green-600" />
            </div>
            <p className="text-3xl mb-1">{selectedHOD.placedStudents}</p>
            <p className="text-sm text-muted-foreground">Students Placed</p>
            <Badge className="mt-2 bg-green-100 text-green-700">
              {Math.round((selectedHOD.placedStudents / selectedHOD.totalStudents) * 100)}% Success Rate
            </Badge>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
            <p className="text-3xl mb-1">₹{selectedHOD.averagePackage} LPA</p>
            <p className="text-sm text-muted-foreground">Average Package</p>
          </div>
        </div>
      </Card>
    </div>
  );
}