import { useState } from 'react';
import { PlacementDrive } from '../types';
import { mockPlacementDrives, indianCities, indianStates, branches } from '../data/mockData';
import { PlacementDriveCard } from './PlacementDriveCard';
import { DriveDetailsDialog } from './DriveDetailsDialog';
import { SubscriptionDialog } from './SubscriptionDialog';
import { ApplicationTracker } from './ApplicationTracker';
import { MessagingCenter } from './MessagingCenter';
import { AnnouncementsBoard } from './AnnouncementsBoard';
import { AnalyticsDashboard } from './AnalyticsDashboard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Plus, TrendingUp, Users, Calendar, Building2, Crown, Lock, FileText, MessageSquare, Megaphone, BarChart } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function RecruiterDashboard() {
  const [selectedDrive, setSelectedDrive] = useState<PlacementDrive | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isPostDriveOpen, setIsPostDriveOpen] = useState(false);
  const [isSubscriptionOpen, setIsSubscriptionOpen] = useState(false);
  const [hasSubscription, setHasSubscription] = useState(false);
  const [myDrives] = useState<PlacementDrive[]>(
    mockPlacementDrives.filter(d => ['1', '2', '6', '8'].includes(d.id))
  );

  const handleViewDetails = (drive: PlacementDrive) => {
    setSelectedDrive(drive);
    setIsDetailsOpen(true);
  };

  const handlePostDrive = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Check subscription for posting more drives
    if (!hasSubscription && myDrives.length >= 2) {
      toast.error('Subscription Required', {
        description: 'Upgrade to annual plan to post unlimited drives.'
      });
      setIsPostDriveOpen(false);
      setIsSubscriptionOpen(true);
      return;
    }

    toast.success('Placement Drive Posted Successfully!', {
      description: 'Your drive will be visible to students after HOD approval.'
    });
    setIsPostDriveOpen(false);
  };

  const handleSubscribe = (plan: 'monthly' | 'annual') => {
    setHasSubscription(true);
    toast.success('Subscription Activated!', {
      description: 'You can now post unlimited placement drives.'
    });
  };

  const totalRegistrations = myDrives.reduce((sum, drive) => sum + drive.registeredStudents, 0);
  const totalSeats = myDrives.reduce((sum, drive) => sum + drive.totalSeats, 0);
  const activeDrives = myDrives.filter(d => d.status === 'Open' || d.status === 'Upcoming').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1>Recruiter Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Manage your placement drives and connect with talented students
          </p>
        </div>
        <div className="flex gap-3">
          {!hasSubscription && (
            <Button 
              variant="outline" 
              className="gap-2 border-yellow-500 text-yellow-700 hover:bg-yellow-50"
              onClick={() => setIsSubscriptionOpen(true)}
            >
              <Crown className="h-4 w-4" />
              Upgrade Now
            </Button>
          )}
          {hasSubscription && (
            <Badge className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white px-4 py-2">
              <Crown className="h-4 w-4 mr-2" />
              Premium Recruiter
            </Badge>
          )}
          <Dialog open={isPostDriveOpen} onOpenChange={setIsPostDriveOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Post New Drive
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Post New Placement Drive</DialogTitle>
              <DialogDescription>
                Fill in the details to create a new placement drive
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handlePostDrive} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="company">Company Name</Label>
                  <Input id="company" placeholder="e.g., Tech Corp India" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="position">Position</Label>
                  <Input id="position" placeholder="e.g., Software Engineer" required />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Select required>
                    <SelectTrigger id="city">
                      <SelectValue placeholder="Select city" />
                    </SelectTrigger>
                    <SelectContent>
                      {indianCities.map(city => (
                        <SelectItem key={city} value={city}>{city}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Select required>
                    <SelectTrigger id="state">
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      {indianStates.map(state => (
                        <SelectItem key={state} value={state}>{state}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Venue Address</Label>
                <Input id="location" placeholder="Complete address" required />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="driveDate">Drive Date</Label>
                  <Input id="driveDate" type="date" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="deadline">Registration Deadline</Label>
                  <Input id="deadline" type="date" required />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="minPackage">Min Package (LPA)</Label>
                  <Input id="minPackage" type="number" step="0.1" placeholder="3.5" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxPackage">Max Package (LPA)</Label>
                  <Input id="maxPackage" type="number" step="0.1" placeholder="7.0" required />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="minCGPA">Minimum CGPA</Label>
                  <Input id="minCGPA" type="number" step="0.1" placeholder="7.0" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="totalSeats">Total Seats</Label>
                  <Input id="totalSeats" type="number" placeholder="50" required />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="driveType">Drive Type</Label>
                <Select required>
                  <SelectTrigger id="driveType">
                    <SelectValue placeholder="Select drive type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="On-Campus">On-Campus</SelectItem>
                    <SelectItem value="Off-Campus">Off-Campus</SelectItem>
                    <SelectItem value="Pool Campus">Pool Campus</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Eligible Branches</Label>
                <div className="flex flex-wrap gap-2 p-3 border rounded-md">
                  {branches.map(branch => (
                    <Badge key={branch} variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                      {branch}
                    </Badge>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">Click to select/deselect branches</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Job Description</Label>
                <Textarea 
                  id="description" 
                  placeholder="Describe the role, responsibilities, and what makes this opportunity great..."
                  rows={4}
                  required
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" className="flex-1" onClick={() => setIsPostDriveOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="flex-1">
                  Post Drive
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Free trial limitation banner */}
      {!hasSubscription && (
        <Alert className="bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
          <Lock className="h-4 w-4" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <div>
                <strong>Free Trial:</strong> You've posted {myDrives.length}/2 drives. 
                Upgrade to annual plan (₹6,999/year) for unlimited postings and premium features!
              </div>
              <Button 
                size="sm" 
                onClick={() => setIsSubscriptionOpen(true)}
                className="ml-4 gap-2"
              >
                <Crown className="h-4 w-4" />
                Upgrade
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Main Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="flex flex-wrap h-auto">
          <TabsTrigger value="overview">
            <Building2 className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="applications">
            <FileText className="h-4 w-4 mr-2" />
            Applications
          </TabsTrigger>
          <TabsTrigger value="messages">
            Messages
          </TabsTrigger>
          <TabsTrigger value="announcements">
            Announcements
          </TabsTrigger>
          <TabsTrigger value="analytics">
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Total Drives</CardDescription>
            <CardTitle className="text-3xl">{myDrives.length}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Building2 className="h-4 w-4" />
              <span>All time</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Active Drives</CardDescription>
            <CardTitle className="text-3xl">{activeDrives}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-green-600">
              <TrendingUp className="h-4 w-4" />
              <span>Currently open</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Total Registrations</CardDescription>
            <CardTitle className="text-3xl">{totalRegistrations}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{totalSeats} total seats</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Average Fill Rate</CardDescription>
            <CardTitle className="text-3xl">
              {Math.round((totalRegistrations / totalSeats) * 100)}%
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>Registration rate</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* My Drives */}
      <div>
        <h2 className="mb-4">My Placement Drives</h2>
        {myDrives.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myDrives.map(drive => (
              <PlacementDriveCard
                key={drive.id}
                drive={drive}
                onViewDetails={handleViewDetails}
                showActions={true}
                userRole="recruiter"
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3>No drives posted yet</h3>
              <p className="text-muted-foreground mt-2 mb-4">
                Start by posting your first placement drive
              </p>
              <Button onClick={() => setIsPostDriveOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Post Your First Drive
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

        </TabsContent>

        <TabsContent value="applications">
          <ApplicationTracker userRole="recruiter" />
        </TabsContent>

        <TabsContent value="messages">
          <MessagingCenter userRole="recruiter" />
        </TabsContent>

        <TabsContent value="announcements">
          <AnnouncementsBoard userRole="recruiter" />
        </TabsContent>

        <TabsContent value="analytics">
          <AnalyticsDashboard />
        </TabsContent>
      </Tabs>

      {/* Details Dialog */}
      <DriveDetailsDialog
        drive={selectedDrive}
        open={isDetailsOpen}
        onOpenChange={setIsDetailsOpen}
        userRole="recruiter"
      />

      {/* Subscription Dialog */}
      <SubscriptionDialog
        open={isSubscriptionOpen}
        onOpenChange={setIsSubscriptionOpen}
        userRole="recruiter"
        onSubscribe={handleSubscribe}
      />
    </div>
  );
}