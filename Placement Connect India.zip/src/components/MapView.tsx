import { useEffect, useRef, useState } from 'react';
import { PlacementDrive } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from './ui/select';
import { MapPin, Navigation, Filter, X, Building2, Calendar } from 'lucide-react';

interface MapViewProps {
  drives: PlacementDrive[];
  onDriveSelect?: (drive: PlacementDrive) => void;
}

export function MapView({ drives, onDriveSelect }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [selectedDrive, setSelectedDrive] = useState<PlacementDrive | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [mapInstance, setMapInstance] = useState<any>(null);

  const filteredDrives = drives.filter(drive => {
    if (!drive.coordinates) return false;
    const matchesStatus = filterStatus === 'all' || drive.status === filterStatus;
    const matchesType = filterType === 'all' || drive.type === filterType;
    return matchesStatus && matchesType;
  });

  useEffect(() => {
    // Dynamically load Leaflet CSS
    if (!document.getElementById('leaflet-css')) {
      const link = document.createElement('link');
      link.id = 'leaflet-css';
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }

    // Dynamically load Leaflet JS
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    script.async = true;
    script.onload = initializeMap;
    document.body.appendChild(script);

    return () => {
      if (mapInstance) {
        mapInstance.remove();
      }
    };
  }, []);

  useEffect(() => {
    if (mapInstance) {
      updateMarkers();
    }
  }, [filteredDrives, mapInstance]);

  const initializeMap = () => {
    if (!mapRef.current || mapInstance) return;

    // @ts-ignore - Leaflet is loaded dynamically
    const L = window.L;
    if (!L) return;

    const map = L.map(mapRef.current, {
      center: [20.5937, 78.9629], // Center of India
      zoom: 5,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 18,
    }).addTo(map);

    setMapInstance(map);
  };

  const updateMarkers = () => {
    if (!mapInstance) return;

    // @ts-ignore
    const L = window.L;
    if (!L) return;

    // Clear existing markers
    mapInstance.eachLayer((layer: any) => {
      if (layer instanceof L.Marker) {
        mapInstance.removeLayer(layer);
      }
    });

    // Add markers for filtered drives
    filteredDrives.forEach(drive => {
      if (drive.coordinates) {
        const statusColors: Record<string, string> = {
          'Open': '#22c55e',
          'Upcoming': '#3b82f6',
          'Closed': '#ef4444',
          'Completed': '#9ca3af'
        };

        const color = statusColors[drive.status] || '#3b82f6';

        const customIcon = L.divIcon({
          className: 'custom-marker',
          html: `
            <div style="position: relative;">
              <div style="
                width: 32px;
                height: 32px;
                background: ${color};
                border: 3px solid white;
                border-radius: 50%;
                box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
              ">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
                  <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                  <circle cx="12" cy="10" r="3" fill="${color}"/>
                </svg>
              </div>
              <div style="
                position: absolute;
                top: -24px;
                left: 50%;
                transform: translateX(-50%);
                background: white;
                padding: 2px 8px;
                border-radius: 4px;
                white-space: nowrap;
                font-size: 11px;
                font-weight: 600;
                box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                display: none;
              " class="marker-label">${drive.company}</div>
            </div>
          `,
          iconSize: [32, 32],
          iconAnchor: [16, 32],
        });

        const marker = L.marker([drive.coordinates.lat, drive.coordinates.lng], {
          icon: customIcon
        }).addTo(mapInstance);

        marker.on('click', () => {
          setSelectedDrive(drive);
          mapInstance.setView([drive.coordinates!.lat, drive.coordinates!.lng], 12, {
            animate: true
          });
        });

        marker.on('mouseover', (e: any) => {
          const label = e.target._icon.querySelector('.marker-label');
          if (label) label.style.display = 'block';
        });

        marker.on('mouseout', (e: any) => {
          const label = e.target._icon.querySelector('.marker-label');
          if (label) label.style.display = 'none';
        });
      }
    });
  };

  const clearFilters = () => {
    setFilterStatus('all');
    setFilterType('all');
  };

  const centerOnDrive = (drive: PlacementDrive) => {
    if (mapInstance && drive.coordinates) {
      mapInstance.setView([drive.coordinates.lat, drive.coordinates.lng], 12, {
        animate: true
      });
      setSelectedDrive(drive);
    }
  };

  const activeFiltersCount = 
    (filterStatus !== 'all' ? 1 : 0) +
    (filterType !== 'all' ? 1 : 0);

  return (
    <div className="space-y-4">
      {/* Filters */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Drive Locations Map
            </CardTitle>
            <Badge variant="secondary">{filteredDrives.length} drives</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <div className="flex-1 min-w-[200px]">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <SelectValue placeholder="Status" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Open">Open</SelectItem>
                  <SelectItem value="Upcoming">Upcoming</SelectItem>
                  <SelectItem value="Closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 min-w-[200px]">
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    <SelectValue placeholder="Type" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="On-Campus">On-Campus</SelectItem>
                  <SelectItem value="Off-Campus">Off-Campus</SelectItem>
                  <SelectItem value="Pool Campus">Pool Campus</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {activeFiltersCount > 0 && (
              <Button 
                variant="outline" 
                onClick={clearFilters}
                className="gap-2"
              >
                <X className="h-4 w-4" />
                Clear
                <Badge variant="secondary">{activeFiltersCount}</Badge>
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Map and Drive List */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Map */}
        <div className="lg:col-span-2">
          <Card className="overflow-hidden">
            <div 
              ref={mapRef} 
              className="w-full h-[500px] bg-gray-100"
            />
          </Card>
        </div>

        {/* Drive List */}
        <div className="space-y-3 max-h-[500px] overflow-y-auto">
          {filteredDrives.length > 0 ? (
            filteredDrives.map(drive => (
              <Card 
                key={drive.id} 
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedDrive?.id === drive.id ? 'border-primary border-2' : ''
                }`}
                onClick={() => centerOnDrive(drive)}
              >
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-sm truncate">{drive.company}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-1 truncate">
                        {drive.position}
                      </p>
                    </div>
                    <Badge 
                      variant="secondary" 
                      className={
                        drive.status === 'Open' ? 'bg-green-100 text-green-700' :
                        drive.status === 'Upcoming' ? 'bg-blue-100 text-blue-700' :
                        'bg-gray-100 text-gray-700'
                      }
                    >
                      {drive.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span className="truncate">{drive.city}, {drive.state}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{new Date(drive.date).toLocaleDateString('en-IN')}</span>
                    </div>
                    {onDriveSelect && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full mt-2"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDriveSelect(drive);
                        }}
                      >
                        View Details
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <Filter className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">
                  No drives match your filters
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Legend */}
      <Card>
        <CardContent className="py-3">
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
              <span>Open</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500"></div>
              <span>Upcoming</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <span>Closed</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-gray-400"></div>
              <span>Completed</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
