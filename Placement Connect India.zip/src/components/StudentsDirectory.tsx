import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { 
  Mail, Phone, GraduationCap, BookOpen, Award, Briefcase, 
  Search, Filter, TrendingUp, AlertCircle, FileText, Download, Eye
} from 'lucide-react';
import { StudentProfile } from '../types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { toast } from 'sonner@2.0.3';

interface StudentsDirectoryProps {
  students: StudentProfile[];
}

export function StudentsDirectory({ students }: StudentsDirectoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<StudentProfile | null>(null);
  const [filterBranch, setFilterBranch] = useState<string>('all');

  const branches = Array.from(new Set(students.map(s => s.branch)));

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.branch.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBranch = filterBranch === 'all' || student.branch === filterBranch;
    return matchesSearch && matchesBranch;
  });

  return (
    <div className="space-y-6">
      {/* Search and Filter */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, or branch..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <select
              value={filterBranch}
              onChange={(e) => setFilterBranch(e.target.value)}
              className="border rounded-md px-3 py-2 text-sm"
            >
              <option value="all">All Branches</option>
              {branches.map(branch => (
                <option key={branch} value={branch}>{branch}</option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* Students Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStudents.map(student => (
          <Card 
            key={student.id} 
            className="p-6 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => setSelectedStudent(student)}
          >
            <div className="flex items-start gap-4 mb-4">
              {student.photo && (
                <img 
                  src={student.photo} 
                  alt={student.name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-primary"
                />
              )}
              <div className="flex-1">
                <h3 className="mb-1">{student.name}</h3>
                <p className="text-sm text-muted-foreground">{student.branch}</p>
                <Badge variant="outline" className="mt-1">
                  {student.batch}
                </Badge>
              </div>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">CGPA</span>
                <span className={student.cgpa >= 8.0 ? 'text-green-600' : student.cgpa >= 7.0 ? 'text-blue-600' : 'text-orange-600'}>
                  {student.cgpa.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Semester</span>
                <span>{student.semester}</span>
              </div>
              {student.backlogs > 0 && (
                <div className="flex items-center gap-2 text-orange-600">
                  <AlertCircle className="h-4 w-4" />
                  <span>{student.backlogs} Backlogs</span>
                </div>
              )}
            </div>

            <Button 
              variant="outline" 
              size="sm" 
              className="w-full mt-4"
              onClick={(e) => {
                e.stopPropagation();
                setSelectedStudent(student);
              }}
            >
              View Details
            </Button>
          </Card>
        ))}
      </div>

      {filteredStudents.length === 0 && (
        <Card className="p-12 text-center">
          <p className="text-muted-foreground">No students found matching your criteria</p>
        </Card>
      )}

      {/* Student Detail Dialog */}
      <Dialog open={!!selectedStudent} onOpenChange={() => setSelectedStudent(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedStudent && (
            <>
              <DialogHeader>
                <DialogTitle>Student Profile</DialogTitle>
              </DialogHeader>

              <div className="space-y-6">
                {/* Profile Header */}
                <div className="flex items-start gap-6">
                  {selectedStudent.photo && (
                    <img 
                      src={selectedStudent.photo} 
                      alt={selectedStudent.name}
                      className="w-24 h-24 rounded-full object-cover border-2 border-primary"
                    />
                  )}
                  <div className="flex-1">
                    <h2 className="text-2xl mb-1">{selectedStudent.name}</h2>
                    <p className="text-muted-foreground mb-2">{selectedStudent.branch}</p>
                    <div className="flex flex-wrap gap-2">
                      <Badge>{selectedStudent.batch}</Badge>
                      <Badge variant="outline">Semester {selectedStudent.semester}</Badge>
                      <Badge className={selectedStudent.cgpa >= 8.0 ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}>
                        CGPA: {selectedStudent.cgpa.toFixed(2)}
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  {/* Contact Information */}
                  <Card className="p-4">
                    <h3 className="mb-3 flex items-center gap-2">
                      <Mail className="h-4 w-4 text-primary" />
                      Contact Information
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div>
                        <p className="text-muted-foreground">Email</p>
                        <a href={`mailto:${selectedStudent.email}`} className="text-blue-600 hover:underline">
                          {selectedStudent.email}
                        </a>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Phone</p>
                        <a href={`tel:${selectedStudent.phone}`} className="hover:underline">
                          {selectedStudent.phone}
                        </a>
                      </div>
                      <div>
                        <p className="text-muted-foreground">College</p>
                        <p>{selectedStudent.college}</p>
                      </div>
                    </div>
                  </Card>

                  {/* Academic Performance */}
                  <Card className="p-4">
                    <h3 className="mb-3 flex items-center gap-2">
                      <BookOpen className="h-4 w-4 text-primary" />
                      Academic Performance
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">CGPA</span>
                        <span>{selectedStudent.cgpa.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">10th Marks</span>
                        <span>{selectedStudent.tenthMarks}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">12th Marks</span>
                        <span>{selectedStudent.twelfthMarks}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Backlogs</span>
                        <span className={selectedStudent.backlogs > 0 ? 'text-orange-600' : 'text-green-600'}>
                          {selectedStudent.backlogs}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Graduation Year</span>
                        <span>{selectedStudent.graduationYear}</span>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Skills */}
                <Card className="p-4">
                  <h3 className="mb-3 flex items-center gap-2">
                    <Award className="h-4 w-4 text-primary" />
                    Skills
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedStudent.skills.map((skill, index) => (
                      <Badge key={index} variant="outline">{skill}</Badge>
                    ))}
                  </div>
                </Card>

                {/* Internships */}
                {selectedStudent.internships && selectedStudent.internships.length > 0 && (
                  <Card className="p-4">
                    <h3 className="mb-3 flex items-center gap-2">
                      <Briefcase className="h-4 w-4 text-primary" />
                      Internships
                    </h3>
                    <ul className="space-y-2">
                      {selectedStudent.internships.map((internship, index) => (
                        <li key={index} className="text-sm flex items-start gap-2">
                          <span className="text-primary mt-1">•</span>
                          <span>{internship}</span>
                        </li>
                      ))}
                    </ul>
                  </Card>
                )}

                {/* Projects */}
                {selectedStudent.projects && selectedStudent.projects.length > 0 && (
                  <Card className="p-4">
                    <h3 className="mb-3 flex items-center gap-2">
                      <FileText className="h-4 w-4 text-primary" />
                      Projects
                    </h3>
                    <ul className="space-y-2">
                      {selectedStudent.projects.map((project, index) => (
                        <li key={index} className="text-sm flex items-start gap-2">
                          <span className="text-primary mt-1">•</span>
                          <span>{project}</span>
                        </li>
                      ))}
                    </ul>
                  </Card>
                )}

                {/* Preferences */}
                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="p-4">
                    <h3 className="mb-3 flex items-center gap-2">
                      <GraduationCap className="h-4 w-4 text-primary" />
                      Preferred Companies
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedStudent.preferredCompanies.map((company, index) => (
                        <Badge key={index} variant="secondary">{company}</Badge>
                      ))}
                    </div>
                  </Card>

                  <Card className="p-4">
                    <h3 className="mb-3 flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      Career Preferences
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div>
                        <p className="text-muted-foreground">Preferred Locations</p>
                        <p>{selectedStudent.preferredLocations.join(', ')}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Minimum Package</p>
                        <p>₹{selectedStudent.minPackage} LPA</p>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Resume Section */}
                {selectedStudent.resumeUrl && (
                  <Card className="p-4">
                    <h3 className="mb-3 flex items-center gap-2">
                      <FileText className="h-4 w-4 text-primary" />
                      Resume
                    </h3>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => {
                          window.open(selectedStudent.resumeUrl, '_blank');
                          toast.success('Opening resume in new tab');
                        }}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View Resume
                      </Button>
                      <Button 
                        variant="outline"
                        className="flex-1"
                        onClick={() => {
                          // Simulate download
                          const link = document.createElement('a');
                          link.href = selectedStudent.resumeUrl!;
                          link.download = `${selectedStudent.name.replace(/\s+/g, '_')}_Resume.pdf`;
                          document.body.appendChild(link);
                          link.click();
                          document.body.removeChild(link);
                          toast.success('Resume downloaded successfully!');
                        }}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download Resume
                      </Button>
                    </div>
                  </Card>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}