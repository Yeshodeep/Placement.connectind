# 🎓 PlacementConnect India

**Connecting Students, Recruiters & Colleges Across India**

PlacementConnect India is a comprehensive placement drive platform that bridges the gap between students, recruiters, and college administrators. Built with React, TypeScript, and Tailwind CSS, it provides a seamless experience for discovering, managing, and tracking placement opportunities across India.

![PlacementConnect India](https://images.unsplash.com/photo-1635246550194-11af93a2763f?w=1200&h=400&fit=crop)

---

## ✨ Features

### 🎯 For Students
- **Browse Placement Drives** - Discover opportunities from 500+ companies across major Indian cities
- **Advanced Filtering** - Filter by location, company, branch, package, and eligibility criteria
- **Application Tracking** - Monitor application status in real-time
- **Resume Builder** - Upload and manage PDF resumes
- **Interactive Map** - Visualize placement drives geographically
- **HOD Information** - View and connect with college HOD details
- **Subscription Plans** - ₹10/month for premium features

### 💼 For Recruiters
- **Post Placement Drives** - Create and manage placement opportunities
- **Application Management** - Review student applications and resumes
- **Analytics Dashboard** - Track drive performance and student engagement
- **Student Directory** - Search and filter student profiles
- **Messaging Center** - Communicate with students and colleges
- **Subscription Plans** - ₹6,999/year for unlimited postings

### 🏛️ For College HODs
- **Drive Approval System** - Review and approve placement drives
- **Student Management** - Comprehensive student directory with profiles
- **Placement Analytics** - Track placement statistics and trends
- **Resume Access** - View and download student resumes
- **Announcements Board** - Post important updates and notifications
- **Bidirectional Information** - Share college and department details with students

---

## 🚀 Tech Stack

- **Frontend Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS v4
- **UI Components**: Custom component library (shadcn/ui inspired)
- **State Management**: React Hooks (useState, useEffect)
- **Data Visualization**: Recharts
- **Icons**: Lucide React
- **Maps**: Leaflet & React-Leaflet
- **Animations**: Motion (Framer Motion)
- **Notifications**: Sonner
- **Storage**: LocalStorage for authentication & data persistence
- **Build Tool**: Vite

---

## 📋 Prerequisites

Before you begin, ensure you have the following installed:
- **Node.js** (v16 or higher)
- **npm** or **yarn** package manager

---

## 🛠️ Installation & Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/placementconnect-india.git
   cd placementconnect-india
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Start development server**
   ```bash
   npm run dev
   # or
   yarn dev
   ```

4. **Open in browser**
   ```
   Navigate to http://localhost:5173
   ```

---

## 🔐 Authentication

The app includes a complete authentication system with:
- **Sign Up** - Role-specific registration (Student/Recruiter/HOD)
- **Login** - Credential-based authentication
- **Forgot Password** - Password reset with temporary password generation
- **Session Persistence** - Stay logged in across page refreshes

### Default Demo Accounts

Three demo accounts are pre-configured for testing:

**Student Account**
- Email: `rahul.student@example.com`
- Password: `student123`

**Recruiter Account**
- Email: `priya.recruiter@tcs.com`
- Password: `recruiter123`

**HOD Account**
- Email: `amit.hod@iitdelhi.ac.in`
- Password: `hod123`

---

## 📁 Project Structure

```
placementconnect-india/
├── components/
│   ├── StudentDashboard.tsx       # Student interface
│   ├── RecruiterDashboard.tsx     # Recruiter interface
│   ├── HODDashboard.tsx           # HOD interface
│   ├── LoginForm.tsx              # Login component
│   ├── SignUpForm.tsx             # Registration component
│   ├── ForgotPasswordForm.tsx     # Password reset
│   ├── MapView.tsx                # Interactive map
│   ├── ResumeBuilder.tsx          # Resume upload
│   ├── AnalyticsDashboard.tsx     # Analytics & charts
│   ├── MessagingCenter.tsx        # Messaging system
│   └── ui/                        # Reusable UI components
├── utils/
│   └── auth.ts                    # Authentication utilities
├── types/
│   └── index.ts                   # TypeScript type definitions
├── data/
│   └── mockData.ts                # Mock placement drive data
├── styles/
│   └── globals.css                # Global styles & Tailwind config
├── App.tsx                        # Main application component
└── README.md                      # You are here!
```

---

## 🎨 Key Features Breakdown

### Interactive Map View
- Real-time visualization of placement drives across India
- City-based filtering and clustering
- Company logos and drive details on markers
- Responsive map controls

### Analytics Dashboard
- Drive performance metrics
- Application status tracking
- Package distribution charts
- City-wise placement trends
- Monthly placement analytics

### Resume Management
- PDF upload functionality
- View and download resumes
- Resume association with student profiles
- Access control based on user roles

### Subscription System
- Student plans: ₹10/month
- Recruiter plans: ₹6,999/year
- Mock Razorpay integration (test mode)
- Subscription status tracking

---

## 🌐 Deployment

### Deploy to Vercel (Recommended)

1. Push your code to GitHub
2. Import project in Vercel dashboard
3. Deploy with zero configuration

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

### Deploy to Netlify

1. Build the project
   ```bash
   npm run build
   ```
2. Deploy the `dist` folder to Netlify

### Deploy to Other Platforms
See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed deployment guides.

---

## 🤝 Contributing

Contributions are welcome! Please check out our [Contributing Guidelines](./CONTRIBUTING.md).

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📝 Mock Data

The application uses realistic mock data including:
- **Companies**: TCS, Infosys, Wipro, Amazon, Microsoft, Google, Flipkart, and more
- **Cities**: Mumbai, Bangalore, Delhi, Hyderabad, Chennai, Pune, Kolkata, etc.
- **Branches**: Computer Science, IT, Electronics, Mechanical, Civil, and more
- **Package Ranges**: ₹3 LPA to ₹50+ LPA

All data is stored in `data/mockData.ts` and can be easily customized.

---

## 🔒 Security Note

**Important**: This is a demo application using localStorage for data persistence. For production use:
- Implement proper backend API with database
- Use secure authentication (JWT, OAuth)
- Never store passwords in plain text
- Implement proper data validation and sanitization
- Use HTTPS for all communications

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- Built with [React](https://react.dev/)
- UI components inspired by [shadcn/ui](https://ui.shadcn.com/)
- Icons from [Lucide](https://lucide.dev/)
- Maps powered by [Leaflet](https://leafletjs.com/)
- Charts by [Recharts](https://recharts.org/)
- Images from [Unsplash](https://unsplash.com/)

---

## 📧 Contact

For questions, feedback, or collaboration opportunities:
- **Email**: your.email@example.com
- **LinkedIn**: [Your LinkedIn](https://linkedin.com/in/yourprofile)
- **Twitter**: [@yourhandle](https://twitter.com/yourhandle)
- **Dev.to**: [@yourhandle](https://dev.to/yourhandle)

---

## 🌟 Show Your Support

If you found this project helpful, please give it a ⭐️ on GitHub!

---

**Made with ❤️ for the Indian placement ecosystem**
