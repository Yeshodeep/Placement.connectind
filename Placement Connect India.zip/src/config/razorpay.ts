/**
 * Razorpay Payment Configuration
 *
 * ⚠️ IMPORTANT: Use PAYMENT LINKS or PAYMENT PAGES (No verification needed!)
 *
 * DON'T use "Payment Gateway" - that requires domain verification
 * DO use "Payment Links" or "Payment Pages" - works immediately, no verification!
 *
 * HOW TO SET UP:
 *
 * OPTION 1: Payment Links (Recommended - Simplest)
 * 1. Go to https://dashboard.razorpay.com/
 * 2. Click "Payment Links" in left sidebar
 * 3. Click "Create Payment Link"
 * 4. Create two links:
 *    - Student Monthly: ₹10
 *    - Recruiter Annual: ₹6999
 * 5. Copy the URLs (format: https://rzp.io/l/xxxxxxxx)
 * 6. Paste them below
 *
 * OPTION 2: Payment Pages (Better for branding)
 * 1. Go to https://dashboard.razorpay.com/
 * 2. Click "Payment Pages" in left sidebar
 * 3. Click "Create New Page"
 * 4. Design your payment page with logo/description
 * 5. Create two pages (Student ₹10, Recruiter ₹6999)
 * 6. Copy the URLs (format: https://pages.razorpay.com/xxxxx)
 * 7. Paste them below
 *
 * ✅ NO WEBSITE VERIFICATION NEEDED for both options!
 */

export const RAZORPAY_PAYMENT_LINKS = {
  // Student Monthly Plan - ₹10/month
  student_monthly: "https://rzp.io/rzp/GmdO1XJ",

  // Recruiter Annual Plan - ₹6999/year
  recruiter_annual: "https://rzp.io/rzp/0q8S6vVK",
};

/**
 * Optional: Add your Razorpay Key ID for verification
 * This is your PUBLIC key - safe to expose in frontend
 * Find it at: Settings > API Keys
 */
export const RAZORPAY_KEY_ID = "YOUR_RAZORPAY_KEY_ID_HERE";

/**
 * IMPORTANT NOTES:
 *
 * 1. MANUAL VERIFICATION NEEDED:
 *    - After payment, you'll need to manually verify payments in Razorpay dashboard
 *    - Then update user subscription status in your app
 *
 * 2. FOR AUTOMATIC VERIFICATION:
 *    - You'll need a backend (Supabase recommended)
 *    - Set up Razorpay webhooks to notify your backend
 *    - Backend will automatically activate subscriptions
 *
 * 3. SECURITY:
 *    - Never expose your Razorpay Key Secret in frontend code
 *    - Only use payment links or Key ID (public key)
 *
 * 4. TESTING:
 *    - Create test payment links first
 *    - Use Razorpay test mode for development
 *    - Switch to live mode only when ready for production
 */