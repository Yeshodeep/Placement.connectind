# 🚀 Razorpay Payment Setup Guide

This guide will help you set up Razorpay payment links to collect subscription payments.

⚠️ **IMPORTANT**: Use **Payment Links** or **Payment Pages** - these DON'T require website verification!

❌ **Don't use**: "Payment Gateway" integration - that requires domain verification which you don't need!

---

## 📋 Step-by-Step Setup

### Step 1: Create Razorpay Account
1. Go to **https://dashboard.razorpay.com/**
2. Sign up with your business details
3. You can test in **Test Mode** immediately (no KYC needed for testing)
4. Complete KYC verification later when you're ready to go live

---

### Step 2: Create Payment Links (NO VERIFICATION NEEDED!)

#### For Student Monthly Plan (₹10/month):

1. In Razorpay Dashboard, click **Payment Links** in left sidebar
2. Click **Create Payment Link**
3. Fill in details:
   - **Title**: Student Monthly Subscription
   - **Description**: Premium access to all placement drives
   - **Amount**: ₹10.00
   - **Payment Purpose**: Subscription
   - **Partial Payments**: Disabled
   - **Expire After**: (Optional) Set expiry if needed
4. Click **Create**
5. **Copy the payment link** (will look like `https://rzp.io/l/xxxxxx`)

#### For Recruiter Annual Plan (₹6999/year):

1. Click **Create Payment Link** again
2. Fill in details:
   - **Title**: Recruiter Annual Subscription
   - **Description**: Post unlimited drives and access premium features
   - **Amount**: ₹6999.00
   - **Payment Purpose**: Subscription
   - **Partial Payments**: Disabled
3. Click **Create**
4. **Copy the payment link**

---

### Step 3: Add Links to Your App

1. Open file: `/config/razorpay.ts`
2. Replace these lines with your actual payment links:

```typescript
export const RAZORPAY_PAYMENT_LINKS = {
  // Paste your student monthly payment link here
  student_monthly: 'https://rzp.io/l/YOUR_STUDENT_LINK',
  
  // Paste your recruiter annual payment link here
  recruiter_annual: 'https://rzp.io/l/YOUR_RECRUITER_LINK',
};
```

3. Save the file

---

### Step 4: Test the Payment Flow

1. Click **Subscribe** button in your app
2. It will open your Razorpay payment link
3. Make a test payment using Razorpay test cards:
   - **Card Number**: 4111 1111 1111 1111
   - **CVV**: Any 3 digits
   - **Expiry**: Any future date
4. Verify payment appears in your Razorpay dashboard

---

## 💰 How to Verify Payments

### Current Setup (Manual Verification):

1. User clicks "Subscribe" → Opens Razorpay payment link
2. User completes payment
3. **You manually check** Razorpay dashboard for payments
4. **You manually activate** subscription in your app
5. User gets access

⚠️ **Limitation**: You need to manually verify each payment and activate subscriptions.

---

## 🔄 Automatic Payment Verification (Recommended)

To automatically verify payments and activate subscriptions, you need:

### What You Need:
- **Backend server** (Supabase recommended)
- **Database** to store user subscriptions
- **Razorpay Webhooks** to receive payment notifications

### How It Works:
1. User completes payment on Razorpay
2. Razorpay sends webhook notification to your backend
3. Backend verifies payment and updates database
4. Subscription activates automatically
5. User gets instant access

### To Set This Up:
You'll need to integrate with Supabase (or another backend). This requires:
- Setting up Razorpay webhooks
- Creating database tables for subscriptions
- Building API endpoints to handle webhooks
- User authentication

---

## 🔐 Security Notes

### ✅ Safe to Add in Frontend:
- Payment Links (public URLs)
- Razorpay Key ID (public key)

### ❌ NEVER Add in Frontend:
- Razorpay Key Secret (private key)
- Webhook secrets
- Database credentials

---

## 💡 Payment Link Features

### What You Can Do:
- Set custom amount
- Add description
- Set expiry date
- Send payment reminders
- Track payment status
- Offer multiple payment methods (UPI, Cards, NetBanking, Wallets)

### What You Can't Do (Without Backend):
- Automatically activate subscriptions
- Track which user paid
- Handle subscription renewals
- Manage refunds programmatically

---

## 📊 Tracking Payments

### In Razorpay Dashboard:
1. Go to **Transactions** → **Payment Links**
2. See all payment link transactions
3. Download reports
4. View payment details (customer info, amount, date)

### Customer Details:
Razorpay captures:
- Customer name
- Email
- Phone number
- Payment method
- Transaction ID

You can use this info to manually verify and activate subscriptions.

---

## 🚀 Going Live

### Before Going Live:
1. ✅ Complete KYC verification
2. ✅ Test all payment flows
3. ✅ Set up webhook notifications (optional but recommended)
4. ✅ Add terms and refund policy
5. ✅ Switch from Test Mode to Live Mode

### To Switch to Live Mode:
1. In Razorpay Dashboard, toggle **Test Mode** → **Live Mode**
2. Create new payment links in Live Mode
3. Update `/config/razorpay.ts` with live payment links

---

## 💰 Settlement & Payouts

- Razorpay charges **2% + ₹0 per transaction** (standard pricing)
- Settlements happen **T+2 days** (2 working days after payment)
- Money is transferred to your linked bank account
- You can check settlement schedule in dashboard

---

## 🆘 Support

- **Razorpay Support**: support@razorpay.com
- **Documentation**: https://razorpay.com/docs/
- **Community**: https://community.razorpay.com/

---

## ⚡ Quick Checklist

- [ ] Created Razorpay account
- [ ] Completed KYC (for live mode)
- [ ] Created Student Monthly payment link (₹10)
- [ ] Created Recruiter Annual payment link (₹6999)
- [ ] Copied payment links to `/config/razorpay.ts`
- [ ] Tested payment flow
- [ ] Verified test payment in dashboard
- [ ] Documented manual verification process
- [ ] Ready to accept payments! 🎉

---

## 🔮 Next Steps (Optional - For Automation)

To fully automate the subscription process:

1. **Set up Supabase** for backend and database
2. **Create database tables** for users and subscriptions
3. **Integrate Razorpay webhooks** to receive payment notifications
4. **Build authentication** system to link payments to users
5. **Automate subscription activation** based on webhook events

This will give you a fully automated subscription system where users get instant access after payment!

---

**Need help?** Check the comments in `/config/razorpay.ts` for more details.
