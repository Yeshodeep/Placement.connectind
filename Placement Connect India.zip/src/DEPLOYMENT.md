# 🚀 Deployment Guide - PlacementConnect India

This guide covers deployment options for PlacementConnect India on various hosting platforms.

---

## 📦 Build for Production

Before deploying, build the optimized production version:

```bash
npm run build
# or
yarn build
```

This creates a `dist` folder with optimized static files ready for deployment.

---

## 🌐 Deployment Options

### 1. Vercel (Recommended) ⚡

**Why Vercel?**
- Zero configuration deployment
- Automatic HTTPS
- Global CDN
- Free tier available
- Instant rollbacks
- Preview deployments for PRs

**Steps:**

1. **Install Vercel CLI** (optional)
   ```bash
   npm install -g vercel
   ```

2. **Deploy via CLI**
   ```bash
   vercel
   ```

3. **Or Deploy via GitHub**
   - Push code to GitHub
   - Go to [vercel.com](https://vercel.com)
   - Click "Import Project"
   - Select your repository
   - Click "Deploy"

**Configuration:**
No configuration needed! Vercel auto-detects Vite projects.

**Custom Domain:**
- Go to Project Settings → Domains
- Add your custom domain
- Update DNS records as instructed

---

### 2. Netlify 🎨

**Why Netlify?**
- Drag-and-drop deployment
- Continuous deployment from Git
- Free HTTPS
- Form handling
- Split testing

**Steps:**

1. **Via Netlify CLI**
   ```bash
   npm install -g netlify-cli
   npm run build
   netlify deploy --prod
   ```

2. **Via Netlify Dashboard**
   - Drag `dist` folder to [app.netlify.com/drop](https://app.netlify.com/drop)
   
3. **Via Git Integration**
   - Connect your Git repository
   - Build command: `npm run build`
   - Publish directory: `dist`

**netlify.toml** (optional):
```toml
[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

---

### 3. GitHub Pages 📄

**Why GitHub Pages?**
- Free hosting for public repositories
- Easy integration with GitHub
- Custom domain support

**Steps:**

1. **Install gh-pages**
   ```bash
   npm install --save-dev gh-pages
   ```

2. **Update package.json**
   ```json
   {
     "homepage": "https://yourusername.github.io/placementconnect-india",
     "scripts": {
       "predeploy": "npm run build",
       "deploy": "gh-pages -d dist"
     }
   }
   ```

3. **Deploy**
   ```bash
   npm run deploy
   ```

4. **Configure GitHub**
   - Go to repository Settings → Pages
   - Source: `gh-pages` branch
   - Save

**Note**: Update `base` in `vite.config.ts`:
```typescript
export default defineConfig({
  base: '/placementconnect-india/',
  // ... other config
})
```

---

### 4. Firebase Hosting 🔥

**Why Firebase?**
- Google Cloud infrastructure
- Fast global CDN
- Free SSL certificates
- Easy rollbacks

**Steps:**

1. **Install Firebase CLI**
   ```bash
   npm install -g firebase-tools
   ```

2. **Login to Firebase**
   ```bash
   firebase login
   ```

3. **Initialize Firebase**
   ```bash
   firebase init hosting
   ```
   - Choose "Use an existing project" or create new
   - Public directory: `dist`
   - Configure as single-page app: `Yes`
   - Don't overwrite index.html

4. **Build and Deploy**
   ```bash
   npm run build
   firebase deploy
   ```

**firebase.json**:
```json
{
  "hosting": {
    "public": "dist",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [
      {
        "source": "**",
        "destination": "/index.html"
      }
    ]
  }
}
```

---

### 5. AWS S3 + CloudFront ☁️

**Why AWS?**
- Enterprise-grade infrastructure
- Fine-grained control
- Integration with AWS services
- Pay-as-you-go pricing

**Steps:**

1. **Create S3 Bucket**
   - Name: `placementconnect-india`
   - Enable static website hosting
   - Bucket policy: Public read access

2. **Upload Build Files**
   ```bash
   aws s3 sync dist/ s3://placementconnect-india --delete
   ```

3. **Configure CloudFront**
   - Create distribution
   - Origin: Your S3 bucket
   - Enable HTTPS
   - Set default root object: `index.html`

4. **Error Pages**
   - Add custom error response for 404 → `/index.html` (200)

**Automated Deployment with GitHub Actions**:
```yaml
name: Deploy to S3
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: '18'
      - run: npm install
      - run: npm run build
      - uses: jakejarvis/s3-sync-action@master
        with:
          args: --delete
        env:
          AWS_S3_BUCKET: ${{ secrets.AWS_S3_BUCKET }}
          AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          SOURCE_DIR: 'dist'
```

---

### 6. Render 🎭

**Why Render?**
- Free tier for static sites
- Automatic deploys from Git
- Custom domains
- Free SSL

**Steps:**

1. **Create New Static Site**
   - Go to [render.com](https://render.com)
   - New → Static Site
   - Connect repository

2. **Configure Build**
   - Build Command: `npm run build`
   - Publish Directory: `dist`

3. **Deploy**
   - Click "Create Static Site"

---

### 7. Cloudflare Pages 🌩️

**Why Cloudflare?**
- Global edge network
- Unlimited bandwidth
- Free SSL
- Fast build times

**Steps:**

1. **Connect Git Repository**
   - Go to [pages.cloudflare.com](https://pages.cloudflare.com)
   - Create a project
   - Connect GitHub/GitLab

2. **Build Settings**
   - Framework: Vite
   - Build command: `npm run build`
   - Build output: `dist`

3. **Deploy**
   - Click "Save and Deploy"

---

## 🔧 Environment Variables

If you add environment variables in the future:

**Vite Format** (`.env`):
```env
VITE_API_URL=https://api.example.com
VITE_RAZORPAY_KEY=your_razorpay_key
```

**Access in Code**:
```typescript
const apiUrl = import.meta.env.VITE_API_URL;
```

**Platform-Specific Setup**:
- **Vercel**: Project Settings → Environment Variables
- **Netlify**: Site Settings → Build & Deploy → Environment
- **GitHub Actions**: Repository Settings → Secrets

---

## 🌍 Custom Domain Setup

### Vercel
1. Project Settings → Domains
2. Add your domain
3. Update DNS A record to Vercel's IP

### Netlify
1. Domain Settings → Add Custom Domain
2. Update nameservers or DNS records

### Cloudflare Pages
1. Custom Domains → Set up a custom domain
2. Automatic DNS configuration if using Cloudflare DNS

---

## 📊 Performance Optimization

### 1. Enable Compression
Most platforms enable Gzip/Brotli by default.

### 2. Cache Headers
Configure cache control for static assets:
```
Cache-Control: public, max-age=31536000, immutable
```

### 3. CDN Configuration
Ensure your platform's CDN is enabled for global distribution.

### 4. Lighthouse Score
Run Google Lighthouse to check performance:
```bash
npm install -g lighthouse
lighthouse https://your-deployment-url.com
```

---

## 🔒 Security Headers

Add security headers (platform-specific):

**Netlify** (`_headers` file in `public/`):
```
/*
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), microphone=(), camera=()
```

**Vercel** (`vercel.json`):
```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        }
      ]
    }
  ]
}
```

---

## 🐛 Troubleshooting

### Routes Not Working (404 on Refresh)
**Problem**: SPA routing breaks on page refresh.

**Solution**: Configure server to redirect all routes to `index.html`:
- Most platforms handle this automatically
- Check for SPA/rewrites configuration

### Build Fails
**Common Issues**:
1. Check Node.js version (requires v16+)
2. Clear node_modules: `rm -rf node_modules && npm install`
3. Check for TypeScript errors: `npm run build`

### Slow Build Times
**Optimization**:
- Use platform's build cache
- Minimize dependencies
- Use `vite.config.ts` optimization settings

---

## 📈 Monitoring & Analytics

### Google Analytics
Add to `index.html`:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### Vercel Analytics
Enable in project settings (included in Pro plan).

### Error Tracking
- [Sentry](https://sentry.io)
- [LogRocket](https://logrocket.com)

---

## ✅ Pre-Deployment Checklist

- [ ] Run `npm run build` successfully
- [ ] Test production build locally: `npm run preview`
- [ ] Remove console.logs and debug code
- [ ] Update contact information in README
- [ ] Test all authentication flows
- [ ] Verify map functionality
- [ ] Check responsive design on mobile
- [ ] Update meta tags for SEO
- [ ] Test subscription/payment flows
- [ ] Add analytics tracking
- [ ] Configure error monitoring

---

## 🎯 Post-Deployment

1. **Test Live Site**
   - All authentication flows
   - Map functionality
   - Resume upload/download
   - Responsive design

2. **Share Your Project**
   - Post on Dev.to
   - Share on Twitter/LinkedIn
   - Submit to Product Hunt
   - Add to GitHub showcase

3. **Monitor Performance**
   - Check Lighthouse scores
   - Monitor error rates
   - Track user analytics

---

**Happy Deploying! 🚀**
