export interface PlacementDrive {
  id: string;
  company: string;
  companyLogo?: string;
  position: string;
  location: string;
  city: string;
  state: string;
  date: string;
  deadline: string;
  eligibility: {
    degree: string[];
    minCGPA: number;
    graduationYear: number[];
    branches: string[];
  };
  package: {
    min: number;
    max: number;
  };
  type: 'On-Campus' | 'Off-Campus' | 'Pool Campus';
  status: 'Open' | 'Closed' | 'Upcoming' | 'Completed';
  registeredStudents: number;
  totalSeats: number;
  colleges: string[];
  description: string;
  requirements: string[];
  rounds: string[];
  postedBy: string;
  postedDate: string;
  approvedByHOD?: boolean;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export type UserRole = 'student' | 'recruiter' | 'hod';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  college?: string;
  department?: string;
  company?: string;
  subscription?: SubscriptionInfo;
}

export interface SubscriptionInfo {
  isActive: boolean;
  plan: 'free' | 'monthly' | 'annual';
  startDate?: string;
  endDate?: string;
  amount?: number;
}

export interface Application {
  id: string;
  driveId: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  studentPhone: string;
  cgpa: number;
  branch: string;
  graduationYear: number;
  resumeUrl?: string;
  status: 'Applied' | 'Shortlisted' | 'Selected' | 'Rejected' | 'Interview Scheduled' | 'On Hold';
  appliedDate: string;
  lastUpdated: string;
  notes?: string;
  interviewDate?: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'drive' | 'application' | 'interview' | 'announcement' | 'system';
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  actionUrl?: string;
  metadata?: Record<string, any>;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
  attachments?: string[];
}

export interface Conversation {
  id: string;
  participants: {
    id: string;
    name: string;
    role: UserRole;
  }[];
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  driveId?: string;
}

export interface Document {
  id: string;
  userId: string;
  type: 'resume' | 'certificate' | 'transcript' | 'offer_letter' | 'other';
  name: string;
  url: string;
  uploadedAt: string;
  size: number;
  verified?: boolean;
}

export interface Announcement {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  title: string;
  content: string;
  type: 'general' | 'urgent' | 'event' | 'update';
  targetAudience: UserRole[];
  createdAt: string;
  expiresAt?: string;
  attachments?: string[];
  isPinned: boolean;
}

export interface StudentProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  college: string;
  branch: string;
  batch: string;
  semester: number;
  cgpa: number;
  graduationYear: number;
  skills: string[];
  preferredLocations: string[];
  preferredCompanies: string[];
  minPackage: number;
  resumeUrl?: string;
  photo?: string;
  tenthMarks: number;
  twelfthMarks: number;
  backlogs: number;
  internships?: string[];
  projects?: string[];
}

export interface HODProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  college: string;
  collegeLogo?: string;
  department: string;
  designation: string;
  experience: number;
  qualifications: string[];
  specialization: string[];
  photo?: string;
  officeAddress: string;
  officeHours: string;
  totalStudents: number;
  placedStudents: number;
  averagePackage: number;
}

export interface AnalyticsData {
  totalDrives: number;
  activeDrives: number;
  totalApplications: number;
  successRate: number;
  drivesByStatus: Record<string, number>;
  drivesByType: Record<string, number>;
  applicationsByStatus: Record<string, number>;
  topCompanies: { name: string; count: number }[];
  placementTrends: { month: string; placements: number }[];
  packageDistribution: { range: string; count: number }[];
  cityWiseData: { city: string; drives: number }[];
}